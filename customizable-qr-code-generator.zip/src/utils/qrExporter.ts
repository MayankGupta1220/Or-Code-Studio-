import QRCodeStyling, { Options } from 'qr-code-styling';
import { QRConfig } from '../types/qr';

export interface ExportOptions {
  resolution: number; // e.g. 512, 1024, 2048
  format: 'png' | 'jpeg' | 'svg' | 'webp';
  includeFrame: boolean;
  filename?: string;
}

export function buildQRCodeStylingOptions(
  data: string,
  config: QRConfig,
  size: number
): Options {
  // Setup gradient or solid dots
  let dotsOptions: Options['dotsOptions'] = {
    type: config.dotType,
    color: config.dotsColor
  };

  if (config.dotsColorType === 'gradient') {
    dotsOptions = {
      type: config.dotType,
      gradient: {
        type: config.dotsGradient.type,
        rotation: (config.dotsGradient.rotation * Math.PI) / 180,
        colorStops: [
          { offset: 0, color: config.dotsGradient.color1 },
          { offset: 1, color: config.dotsGradient.color2 }
        ]
      }
    };
  }

  // Corners Square
  let cornersSquareOptions: Options['cornersSquareOptions'] = {
    type: config.cornerSquareType,
    color: config.customCornersColor ? config.cornerSquareColor : config.dotsColor
  };

  if (!config.customCornersColor && config.dotsColorType === 'gradient') {
    cornersSquareOptions = {
      type: config.cornerSquareType,
      gradient: {
        type: config.dotsGradient.type,
        rotation: (config.dotsGradient.rotation * Math.PI) / 180,
        colorStops: [
          { offset: 0, color: config.dotsGradient.color1 },
          { offset: 1, color: config.dotsGradient.color2 }
        ]
      }
    };
  }

  // Corners Dot
  let cornersDotOptions: Options['cornersDotOptions'] = {
    type: config.cornerDotType,
    color: config.customCornersColor ? config.cornerDotColor : config.dotsColor
  };

  if (!config.customCornersColor && config.dotsColorType === 'gradient') {
    cornersDotOptions = {
      type: config.cornerDotType,
      gradient: {
        type: config.dotsGradient.type,
        rotation: (config.dotsGradient.rotation * Math.PI) / 180,
        colorStops: [
          { offset: 0, color: config.dotsGradient.color1 },
          { offset: 1, color: config.dotsGradient.color2 }
        ]
      }
    };
  }

  // Background Options
  let backgroundOptions: Options['backgroundOptions'] = {
    color: config.bgColorType === 'transparent' ? 'rgba(0,0,0,0)' : config.bgColor
  };

  if (config.bgColorType === 'gradient') {
    backgroundOptions = {
      gradient: {
        type: config.bgGradient.type,
        rotation: (config.bgGradient.rotation * Math.PI) / 180,
        colorStops: [
          { offset: 0, color: config.bgGradient.color1 },
          { offset: 1, color: config.bgGradient.color2 }
        ]
      }
    };
  }

  const options: Options = {
    width: size,
    height: size,
    shape: config.shape,
    data: data,
    margin: config.margin,
    qrOptions: {
      errorCorrectionLevel: config.errorCorrection
    },
    image: config.logo || undefined,
    imageOptions: {
      hideBackgroundDots: config.hideBackgroundDots,
      imageSize: config.logoSize,
      margin: config.logoMargin,
      crossOrigin: 'anonymous'
    },
    dotsOptions,
    cornersSquareOptions,
    cornersDotOptions,
    backgroundOptions
  };

  return options;
}

export async function exportQRCode(
  data: string,
  config: QRConfig,
  options: ExportOptions
): Promise<{ blob: Blob; url: string }> {
  const { resolution, format, includeFrame } = options;

  // If vector SVG is requested and no frame, we can export directly as SVG
  if (format === 'svg' && (!includeFrame || config.frameStyle === 'none')) {
    const qrStyling = new QRCodeStyling({
      ...buildQRCodeStylingOptions(data, config, resolution),
      type: 'svg'
    });
    const blob = (await qrStyling.getRawData('svg')) as Blob;
    const url = URL.createObjectURL(blob);
    return { blob, url };
  }

  // For canvas-based export (PNG, JPEG, WEBP or framed SVG fallback)
  const qrStyling = new QRCodeStyling({
    ...buildQRCodeStylingOptions(data, config, resolution),
    type: 'canvas'
  });

  const rawBlob = (await qrStyling.getRawData('png')) as Blob;

  // If no frame requested or frameStyle is 'none', return rawBlob or convert format
  if (!includeFrame || config.frameStyle === 'none') {
    if (format === 'png') {
      const url = URL.createObjectURL(rawBlob);
      return { blob: rawBlob, url };
    }

    // Convert to JPEG / WEBP
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = resolution;
        canvas.height = resolution;
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject(new Error('Canvas context not available'));

        if (format === 'jpeg') {
          ctx.fillStyle = config.bgColorType === 'transparent' ? '#ffffff' : config.bgColor;
          ctx.fillRect(0, 0, resolution, resolution);
        }
        ctx.drawImage(img, 0, 0);

        const mime = format === 'jpeg' ? 'image/jpeg' : 'image/webp';
        canvas.toBlob((blob) => {
          if (blob) {
            resolve({ blob, url: URL.createObjectURL(blob) });
          } else {
            reject(new Error('Failed to create blob'));
          }
        }, mime, 0.95);
      };
      img.onerror = reject;
      img.src = URL.createObjectURL(rawBlob);
    });
  }

  // Draw framed canvas
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = resolution / 600; // base scale
      let canvasW = resolution;
      let canvasH = resolution;
      let qrX = 0;
      let qrY = 0;
      let qrSize = resolution;

      const style = config.frameStyle;

      if (style === 'bottom-banner') {
        canvasW = resolution;
        canvasH = Math.round(resolution * 1.25);
        qrSize = resolution;
        qrX = 0;
        qrY = 0;
      } else if (style === 'top-badge') {
        canvasW = resolution;
        canvasH = Math.round(resolution * 1.22);
        qrSize = resolution;
        qrX = 0;
        qrY = Math.round(resolution * 0.22);
      } else if (style === 'polaroid') {
        const padding = Math.round(40 * scale);
        qrSize = resolution;
        canvasW = qrSize + padding * 2;
        canvasH = qrSize + padding * 2 + Math.round(100 * scale);
        qrX = padding;
        qrY = padding;
      } else if (style === 'badge-pill' || style === 'modern-card') {
        const padding = Math.round(30 * scale);
        qrSize = resolution;
        canvasW = qrSize + padding * 2;
        canvasH = qrSize + padding * 2 + Math.round(80 * scale);
        qrX = padding;
        qrY = padding;
      }

      const canvas = document.createElement('canvas');
      canvas.width = canvasW;
      canvasH = Math.round(canvasH);
      canvas.height = canvasH;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('Canvas context failed'));

      // Draw background
      ctx.fillStyle = config.bgColorType === 'transparent' ? '#ffffff' : config.bgColor;
      ctx.fillRect(0, 0, canvasW, canvasH);

      // Frame specific decorative container
      if (style === 'bottom-banner') {
        ctx.drawImage(img, qrX, qrY, qrSize, qrSize);

        // Banner box at bottom
        const bannerH = canvasH - qrSize;
        ctx.fillStyle = config.frameColor;
        ctx.fillRect(0, qrSize, canvasW, bannerH);

        // Text
        ctx.fillStyle = config.frameTextColor;
        ctx.font = `bold ${Math.round(28 * scale)}px 'Space Grotesk', 'Plus Jakarta Sans', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(config.frameText || 'SCAN ME', canvasW / 2, qrSize + bannerH / 2);
      } else if (style === 'top-badge') {
        const badgeH = qrY;
        ctx.fillStyle = config.frameColor;
        ctx.fillRect(0, 0, canvasW, badgeH);

        ctx.fillStyle = config.frameTextColor;
        ctx.font = `bold ${Math.round(26 * scale)}px 'Space Grotesk', 'Plus Jakarta Sans', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(config.frameText || 'SCAN ME', canvasW / 2, badgeH / 2);

        ctx.drawImage(img, qrX, qrY, qrSize, qrSize);
      } else if (style === 'polaroid') {
        // Crisp card background
        ctx.fillStyle = config.frameColor || '#ffffff';
        // Rounded card
        roundRect(ctx, 0, 0, canvasW, canvasH, 20 * scale);
        ctx.fill();

        ctx.drawImage(img, qrX, qrY, qrSize, qrSize);

        // Caption text
        ctx.fillStyle = config.frameTextColor || '#000000';
        ctx.font = `700 ${Math.round(28 * scale)}px 'Space Grotesk', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(config.frameText || 'SCAN ME', canvasW / 2, qrY + qrSize + Math.round(50 * scale));
      } else if (style === 'modern-card' || style === 'badge-pill') {
        // Sleek modern card
        ctx.fillStyle = config.frameColor || '#18181b';
        roundRect(ctx, 0, 0, canvasW, canvasH, 24 * scale);
        ctx.fill();

        ctx.drawImage(img, qrX, qrY, qrSize, qrSize);

        // Pill button below
        const pillW = Math.round(240 * scale);
        const pillH = Math.round(50 * scale);
        const pillX = (canvasW - pillW) / 2;
        const pillY = qrY + qrSize + Math.round(15 * scale);

        ctx.fillStyle = config.frameTextColor || '#38bdf8';
        roundRect(ctx, pillX, pillY, pillW, pillH, pillH / 2);
        ctx.fill();

        ctx.fillStyle = config.frameColor || '#090d16';
        ctx.font = `bold ${Math.round(20 * scale)}px 'Space Grotesk', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(config.frameText || 'SCAN ME', canvasW / 2, pillY + pillH / 2);
      }

      const mime = format === 'jpeg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png';
      canvas.toBlob((blob) => {
        if (blob) {
          resolve({ blob, url: URL.createObjectURL(blob) });
        } else {
          reject(new Error('Blob conversion failed'));
        }
      }, mime, 0.95);
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(rawBlob);
  });
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number
) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function copyBlobToClipboard(blob: Blob): Promise<boolean> {
  try {
    if (navigator.clipboard && window.ClipboardItem) {
      // Chrome/Firefox require PNG blob for clipboard
      await navigator.clipboard.write([
        new ClipboardItem({
          [blob.type || 'image/png']: blob
        })
      ]);
      return true;
    }
    return false;
  } catch (err) {
    console.error('Failed to copy to clipboard', err);
    return false;
  }
}
