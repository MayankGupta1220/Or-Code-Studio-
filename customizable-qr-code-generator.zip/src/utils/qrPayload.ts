import { QRDataType } from '../types/qr';

export interface QRDataState {
  type: QRDataType;
  // URL
  url: string;
  // Plain text
  text: string;
  // Wi-Fi
  wifiSsid: string;
  wifiPassword: string;
  wifiEncryption: 'WPA' | 'WEP' | 'nopass';
  wifiHidden: boolean;
  // vCard
  vcardFirstName: string;
  vcardLastName: string;
  vcardPhone: string;
  vcardEmail: string;
  vcardOrg: string;
  vcardTitle: string;
  vcardUrl: string;
  // Email
  emailTo: string;
  emailSubject: string;
  emailBody: string;
  // Phone
  phoneNumber: string;
  // SMS
  smsNumber: string;
  smsMessage: string;
  // WhatsApp
  waNumber: string;
  waMessage: string;
  // UPI
  upiVpa: string;
  upiName: string;
  upiAmount: string;
  upiNote: string;
  // Social
  socialPlatform: 'instagram' | 'twitter' | 'youtube' | 'linkedin' | 'github' | 'spotify' | 'telegram' | 'facebook';
  socialUsername: string;
}

export const initialQRData: QRDataState = {
  type: 'url',
  url: 'https://github.com',
  text: 'Welcome to QR Studio Pro!',
  wifiSsid: 'MyHome_WiFi',
  wifiPassword: 'SuperSecretPassword',
  wifiEncryption: 'WPA',
  wifiHidden: false,
  vcardFirstName: 'Alex',
  vcardLastName: 'Morgan',
  vcardPhone: '+1 555-0199',
  vcardEmail: 'alex.morgan@example.com',
  vcardOrg: 'Tech Innovations Ltd',
  vcardTitle: 'Product Designer',
  vcardUrl: 'https://alexmorgan.design',
  emailTo: 'contact@example.com',
  emailSubject: 'Hello from QR Studio',
  emailBody: 'I scanned your QR code and wanted to connect!',
  phoneNumber: '+1 555-0199',
  smsNumber: '+1 555-0199',
  smsMessage: 'Hi! Let\'s catch up soon.',
  waNumber: '919876543210',
  waMessage: 'Hi, I got your contact via QR Code!',
  upiVpa: 'merchant@upi',
  upiName: 'Store Name',
  upiAmount: '250',
  upiNote: 'Coffee & Snacks',
  socialPlatform: 'instagram',
  socialUsername: 'creativestudio'
};

export function generateQRPayload(state: QRDataState): { payload: string; displaySummary: string } {
  switch (state.type) {
    case 'url': {
      let trimmed = state.url.trim();
      if (!trimmed) {
        return { payload: 'https://example.com', displaySummary: 'Empty URL' };
      }
      if (!/^https?:\/\//i.test(trimmed)) {
        trimmed = 'https://' + trimmed;
      }
      return { payload: trimmed, displaySummary: trimmed };
    }

    case 'text': {
      const val = state.text.trim() || 'QR Code Text';
      return { payload: val, displaySummary: val.slice(0, 40) + (val.length > 40 ? '...' : '') };
    }

    case 'wifi': {
      const enc = state.wifiEncryption;
      const ssid = state.wifiSsid.trim() || 'WiFi_Network';
      const pass = state.wifiPassword;
      const hidden = state.wifiHidden ? 'true' : 'false';
      // Format: WIFI:S:<SSID>;T:<WPA|WEP|nopass>;P:<PASSWORD>;H:<true|false>;;
      const wifiString = `WIFI:S:${ssid};T:${enc};P:${pass};H:${hidden};;`;
      return { payload: wifiString, displaySummary: `Wi-Fi: ${ssid} (${enc})` };
    }

    case 'vcard': {
      const fn = `${state.vcardFirstName.trim()} ${state.vcardLastName.trim()}`.trim() || 'User Contact';
      const lines = [
        'BEGIN:VCARD',
        'VERSION:3.0',
        `N:${state.vcardLastName.trim()};${state.vcardFirstName.trim()};;;`,
        `FN:${fn}`,
        state.vcardOrg ? `ORG:${state.vcardOrg.trim()}` : '',
        state.vcardTitle ? `TITLE:${state.vcardTitle.trim()}` : '',
        state.vcardPhone ? `TEL;TYPE=CELL:${state.vcardPhone.trim()}` : '',
        state.vcardEmail ? `EMAIL:${state.vcardEmail.trim()}` : '',
        state.vcardUrl ? `URL:${state.vcardUrl.trim()}` : '',
        'END:VCARD'
      ].filter(Boolean);
      return { payload: lines.join('\n'), displaySummary: `Contact: ${fn}` };
    }

    case 'email': {
      const to = state.emailTo.trim();
      const subject = encodeURIComponent(state.emailSubject.trim());
      const body = encodeURIComponent(state.emailBody.trim());
      const mailto = `mailto:${to}?subject=${subject}&body=${body}`;
      return { payload: mailto, displaySummary: `Email: ${to}` };
    }

    case 'phone': {
      const num = state.phoneNumber.trim();
      return { payload: `tel:${num}`, displaySummary: `Phone: ${num}` };
    }

    case 'sms': {
      const num = state.smsNumber.trim();
      const msg = encodeURIComponent(state.smsMessage.trim());
      return { payload: `smsto:${num}:${msg}`, displaySummary: `SMS to: ${num}` };
    }

    case 'whatsapp': {
      const cleanNum = state.waNumber.replace(/[^0-9]/g, '');
      const text = encodeURIComponent(state.waMessage.trim());
      const url = `https://wa.me/${cleanNum}?text=${text}`;
      return { payload: url, displaySummary: `WhatsApp: +${cleanNum}` };
    }

    case 'upi': {
      const vpa = state.upiVpa.trim();
      const pn = encodeURIComponent(state.upiName.trim());
      const am = state.upiAmount.trim();
      const tn = encodeURIComponent(state.upiNote.trim());
      let upi = `upi://pay?pa=${vpa}&pn=${pn}`;
      if (am) upi += `&am=${am}&cu=INR`;
      if (tn) upi += `&tn=${tn}`;
      return { payload: upi, displaySummary: `UPI: ${vpa} (${am ? '₹' + am : 'Pay'})` };
    }

    case 'social': {
      const username = state.socialUsername.replace(/^@/, '').trim();
      let socialUrl = '';
      switch (state.socialPlatform) {
        case 'instagram':
          socialUrl = `https://instagram.com/${username}`;
          break;
        case 'twitter':
          socialUrl = `https://x.com/${username}`;
          break;
        case 'youtube':
          socialUrl = `https://youtube.com/@${username}`;
          break;
        case 'linkedin':
          socialUrl = `https://linkedin.com/in/${username}`;
          break;
        case 'github':
          socialUrl = `https://github.com/${username}`;
          break;
        case 'spotify':
          socialUrl = `https://open.spotify.com/user/${username}`;
          break;
        case 'telegram':
          socialUrl = `https://t.me/${username}`;
          break;
        case 'facebook':
          socialUrl = `https://facebook.com/${username}`;
          break;
      }
      return { payload: socialUrl, displaySummary: `${state.socialPlatform.toUpperCase()}: @${username}` };
    }

    default:
      return { payload: 'https://example.com', displaySummary: 'Link' };
  }
}
