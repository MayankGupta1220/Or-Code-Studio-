export interface PresetLogo {
  id: string;
  name: string;
  category: 'social' | 'communication' | 'utility';
  dataUri: string;
}

// Function to convert raw SVG to safe data URI
const svgToDataUri = (svg: string): string => {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};

export const PRESET_LOGOS: PresetLogo[] = [
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    category: 'communication',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#25D366"/>
        <path fill="#ffffff" d="M12.04 4.5a7.54 7.54 0 0 0-6.49 11.37L4.5 19.5l3.75-1a7.54 7.54 0 1 0 3.79-14m0 13.82c-1.15 0-2.28-.31-3.26-.9l-.23-.14-2.42.64.65-2.36-.15-.24a6.26 6.26 0 1 1 5.41 3m3.43-4.68c-.19-.1-1.12-.55-1.29-.61-.17-.07-.3-.1-.42.1-.13.19-.48.61-.59.73-.11.13-.22.14-.41.05a5.2 5.2 0 0 1-1.53-.94 5.73 5.73 0 0 1-1.06-1.32c-.11-.19 0-.3.08-.39.09-.09.19-.22.29-.33.1-.11.13-.19.19-.31.07-.13.03-.24-.02-.33-.05-.1-.42-1.02-.58-1.4-.15-.36-.31-.31-.42-.31h-.36c-.13 0-.33.05-.5.24a2.12 2.12 0 0 0-.66 1.57c0 .92.67 1.81.76 1.94.1.12 2.62 4.02 6.36 5.63.89.38 1.58.61 2.12.78.89.28 1.7.24 2.34.15.72-.11 2.22-.91 2.53-1.78.31-.88.31-1.63.22-1.78-.1-.16-.32-.26-.51-.35z"/>
      </svg>
    `)
  },
  {
    id: 'instagram',
    name: 'Instagram',
    category: 'social',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <defs>
          <linearGradient id="ig-grad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#FFDC80" />
            <stop offset="25%" stop-color="#F77737" />
            <stop offset="50%" stop-color="#E1306C" />
            <stop offset="75%" stop-color="#C13584" />
            <stop offset="100%" stop-color="#833AB4" />
          </linearGradient>
        </defs>
        <rect width="24" height="24" rx="6" fill="url(#ig-grad)"/>
        <circle cx="12" cy="12" r="3.2" fill="none" stroke="#ffffff" stroke-width="1.8"/>
        <rect x="5.5" y="5.5" width="13" height="13" rx="3.5" fill="none" stroke="#ffffff" stroke-width="1.8"/>
        <circle cx="15.8" cy="8.2" r="0.9" fill="#ffffff"/>
      </svg>
    `)
  },
  {
    id: 'youtube',
    name: 'YouTube',
    category: 'social',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <rect width="24" height="24" rx="6" fill="#FF0000"/>
        <path d="M10 8.5v7l6-3.5-6-3.5z" fill="#ffffff"/>
      </svg>
    `)
  },
  {
    id: 'x-twitter',
    name: 'X (Twitter)',
    category: 'social',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <rect width="24" height="24" rx="6" fill="#000000"/>
        <path fill="#ffffff" d="M18.244 4.5h2.574l-5.624 6.428 6.616 8.572h-5.18l-4.058-5.305-4.643 5.305H5.356l6.015-6.876L5 4.5h5.31l3.667 4.848L18.244 4.5zm-.903 13.56h1.426L9.728 5.974H8.198l9.143 12.086z"/>
      </svg>
    `)
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    category: 'social',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <rect width="24" height="24" rx="6" fill="#0A66C2"/>
        <path fill="#ffffff" d="M6.94 8.5A1.56 1.56 0 1 1 7 5.38a1.56 1.56 0 0 1-.06 3.12zM5.5 19V9.89h2.89V19H5.5zm4.56-9.11H12.8v1.25h.04c.4-.75 1.38-1.54 2.84-1.54 3.04 0 3.6 2 3.6 4.6V19h-2.9v-4.22c0-1.01 0-2.3-1.4-2.3-1.4 0-1.62 1.1-1.62 2.23V19H10.06V9.89z"/>
      </svg>
    `)
  },
  {
    id: 'github',
    name: 'GitHub',
    category: 'social',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#24292e"/>
        <path fill="#ffffff" fill-rule="evenodd" d="M12 4.5a7.5 7.5 0 0 0-2.37 14.62c.38.07.51-.16.51-.36v-1.28c-2.09.45-2.53-1-2.53-1-.34-.87-.84-1.1-.84-1.1-.68-.46.05-.45.05-.45.75.05 1.15.77 1.15.77.67 1.15 1.76.82 2.19.63.07-.49.26-.82.48-1.01-1.67-.19-3.43-.84-3.43-3.73 0-.82.29-1.5.78-2.03-.08-.19-.34-.96.07-2 0 0 .64-.2 2.08.77a7.25 7.25 0 0 1 3.79 0c1.44-.98 2.08-.77 2.08-.77.41 1.04.16 1.81.08 2 .49.53.78 1.2.78 2.03 0 2.9-1.76 3.53-3.44 3.72.27.24.52.7.52 1.41v2.1c0 .2.14.44.52.36A7.5 7.5 0 0 0 12 4.5z"/>
      </svg>
    `)
  },
  {
    id: 'spotify',
    name: 'Spotify',
    category: 'social',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#1ED760"/>
        <path fill="#ffffff" d="M16.9 16.4c-.2.3-.5.4-.8.2-2.2-1.4-5-1.7-8.3-1-.4.1-.7-.1-.8-.5-.1-.4.1-.7.5-.8 3.6-.8 6.7-.5 9.2 1.1.3.2.4.6.2 1zm1.2-2.7c-.3.4-.8.5-1.2.3-2.6-1.6-6.5-2-9.5-1.1-.4.1-.9-.1-1-.6-.1-.4.1-.9.6-1 3.5-1 7.8-.5 10.8 1.3.4.2.5.7.3 1.1zm.1-2.9c-3.1-1.8-8.2-2-11.2-1.1-.5.2-1-.1-1.2-.6-.2-.5.1-1 .6-1.2 3.5-1.1 9.2-.9 12.8 1.3.5.3.6.9.3 1.4-.2.4-.8.6-1.3.2z"/>
      </svg>
    `)
  },
  {
    id: 'telegram',
    name: 'Telegram',
    category: 'communication',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#2AABEE"/>
        <path fill="#ffffff" d="M5.5 11.5l11-4.5c.5-.2 1 .1.8.7l-1.9 8.9c-.1.6-.6.8-1 .5l-2.8-2.1-1.4 1.3c-.2.2-.3.3-.6.3l.2-2.9 5.3-4.8c.2-.2 0-.3-.3-.1L8.2 13l-2.7-.8c-.6-.2-.6-.6 0-.7z"/>
      </svg>
    `)
  },
  {
    id: 'wifi',
    name: 'WiFi Network',
    category: 'utility',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#06B6D4"/>
        <path fill="#ffffff" d="M12 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm-4.2-3.8a6 6 0 0 1 8.4 0 .9.9 0 0 0 1.3-1.3 7.8 7.8 0 0 0-11 0 .9.9 0 0 0 1.3 1.3zm-2.8-2.8a10 10 0 0 1 14 0 .9.9 0 1 0 1.3-1.3 11.8 11.8 0 0 0-16.6 0 .9.9 0 0 0 1.3 1.3z"/>
      </svg>
    `)
  },
  {
    id: 'globe',
    name: 'Website / Web',
    category: 'utility',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#6366F1"/>
        <path fill="none" stroke="#ffffff" stroke-width="1.8" d="M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zm-7.6 8h15.2m-13-4h10.8m-10.8 8h10.8M12 4c2.2 2.2 3.5 5 3.5 8s-1.3 5.8-3.5 8c-2.2-2.2-3.5-5-3.5-8s1.3-5.8 3.5-8z"/>
      </svg>
    `)
  },
  {
    id: 'mail',
    name: 'Email / Inbox',
    category: 'communication',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#8B5CF6"/>
        <path fill="#ffffff" d="M6 8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V8zm2 0l4 2.8L16 8H8zm8 8V9.5l-4 2.8-4-2.8V16h8z"/>
      </svg>
    `)
  },
  {
    id: 'upi',
    name: 'UPI / Payment',
    category: 'utility',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#10B981"/>
        <path fill="#ffffff" d="M7 6h10v2.5H7V6zm0 4.5h10V13H7v-2.5zm2.5 5.5h5V18h-5v-2z"/>
      </svg>
    `)
  },
  {
    id: 'heart',
    name: 'Love / Heart',
    category: 'utility',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#F43F5E"/>
        <path fill="#ffffff" d="M12 17.5l-1.2-1.1C6.5 12.5 4 10.3 4 7.6 4 5.3 5.8 3.5 8.1 3.5c1.3 0 2.6.6 3.4 1.6.8-1 2.1-1.6 3.4-1.6 2.3 0 4.1 1.8 4.1 4.1 0 2.7-2.5 4.9-6.8 8.8L12 17.5z"/>
      </svg>
    `)
  },
  {
    id: 'star',
    name: 'Star / VIP',
    category: 'utility',
    dataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48">
        <circle cx="12" cy="12" r="12" fill="#F59E0B"/>
        <path fill="#ffffff" d="M12 5.5l2.1 4.3 4.7.7-3.4 3.3.8 4.7-4.2-2.2-4.2 2.2.8-4.7-3.4-3.3 4.7-.7L12 5.5z"/>
      </svg>
    `)
  }
];
