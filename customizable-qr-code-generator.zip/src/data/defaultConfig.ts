import { QRConfig } from '../types/qr';

export const defaultQRConfig: QRConfig = {
  // Shape & Pattern
  shape: 'square',
  dotType: 'rounded',
  cornerSquareType: 'extra-rounded',
  cornerDotType: 'dot',

  // Dots Color
  dotsColorType: 'gradient',
  dotsColor: '#6366f1',
  dotsGradient: {
    type: 'linear',
    rotation: 45,
    color1: '#6366f1',
    color2: '#a855f7'
  },

  // Corners Color Customization
  customCornersColor: false,
  cornerSquareColor: '#6366f1',
  cornerDotColor: '#a855f7',

  // Background
  bgColorType: 'solid',
  bgColor: '#ffffff',
  bgGradient: {
    type: 'linear',
    rotation: 0,
    color1: '#ffffff',
    color2: '#f1f5f9'
  },

  // Logo
  logo: null,
  logoName: undefined,
  logoSize: 0.35,
  logoMargin: 6,
  hideBackgroundDots: true,
  logoBackground: 'circle',

  // Quality & Margin
  errorCorrection: 'Q',
  margin: 12,

  // Frame
  frameStyle: 'bottom-banner',
  frameText: 'SCAN ME',
  frameColor: '#4f46e5',
  frameTextColor: '#ffffff'
};
