import { QRConfig } from '../types/qr';

export interface QRPreset {
  id: string;
  name: string;
  description: string;
  badge?: string;
  previewGradient: string;
  config: Partial<QRConfig>;
}

export const QR_PRESETS: QRPreset[] = [
  {
    id: 'cyber-neon',
    name: 'Cyber Neon',
    description: 'Electric cyan to vivid magenta futuristic glow',
    badge: 'Popular',
    previewGradient: 'from-cyan-400 to-fuchsia-500',
    config: {
      shape: 'square',
      dotType: 'classy',
      cornerSquareType: 'extra-rounded',
      cornerDotType: 'dot',
      dotsColorType: 'gradient',
      dotsColor: '#06b6d4',
      dotsGradient: {
        type: 'linear',
        rotation: 45,
        color1: '#06b6d4',
        color2: '#d946ef'
      },
      customCornersColor: true,
      cornerSquareColor: '#06b6d4',
      cornerDotColor: '#d946ef',
      bgColorType: 'solid',
      bgColor: '#090d16',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'badge-pill',
      frameText: 'SCAN ME',
      frameColor: '#090d16',
      frameTextColor: '#38bdf8'
    }
  },
  {
    id: 'midnight-gold',
    name: 'Midnight Gold',
    description: 'Rich champagne & amber gold on obsidian slate',
    badge: 'Luxury',
    previewGradient: 'from-amber-200 to-amber-500',
    config: {
      shape: 'square',
      dotType: 'classy-rounded',
      cornerSquareType: 'extra-rounded',
      cornerDotType: 'square',
      dotsColorType: 'gradient',
      dotsColor: '#f59e0b',
      dotsGradient: {
        type: 'linear',
        rotation: 135,
        color1: '#fde68a',
        color2: '#d97706'
      },
      customCornersColor: true,
      cornerSquareColor: '#fde68a',
      cornerDotColor: '#d97706',
      bgColorType: 'solid',
      bgColor: '#0f172a',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'polaroid',
      frameText: 'EXCLUSIVE ACCESS',
      frameColor: '#1e293b',
      frameTextColor: '#fef08a'
    }
  },
  {
    id: 'sunset-glow',
    name: 'Sunset Glow',
    description: 'Warm coral, tangerine and vivid rose gradient',
    badge: 'Trending',
    previewGradient: 'from-orange-400 to-rose-500',
    config: {
      shape: 'square',
      dotType: 'rounded',
      cornerSquareType: 'extra-rounded',
      cornerDotType: 'dot',
      dotsColorType: 'gradient',
      dotsColor: '#f97316',
      dotsGradient: {
        type: 'linear',
        rotation: 90,
        color1: '#fb923c',
        color2: '#f43f5e'
      },
      customCornersColor: false,
      cornerSquareColor: '#f43f5e',
      cornerDotColor: '#fb923c',
      bgColorType: 'solid',
      bgColor: '#ffffff',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'bottom-banner',
      frameText: 'SCAN WITH PHONE',
      frameColor: '#f43f5e',
      frameTextColor: '#ffffff'
    }
  },
  {
    id: 'emerald-mint',
    name: 'Emerald Royale',
    description: 'Fresh mint green to deep luxury emerald',
    previewGradient: 'from-emerald-400 to-teal-600',
    config: {
      shape: 'circle',
      dotType: 'dots',
      cornerSquareType: 'dot',
      cornerDotType: 'dot',
      dotsColorType: 'gradient',
      dotsColor: '#10b981',
      dotsGradient: {
        type: 'radial',
        rotation: 0,
        color1: '#34d399',
        color2: '#047857'
      },
      customCornersColor: true,
      cornerSquareColor: '#059669',
      cornerDotColor: '#34d399',
      bgColorType: 'solid',
      bgColor: '#06201b',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'none',
      frameText: 'SCAN ME',
      frameColor: '#059669',
      frameTextColor: '#a7f3d0'
    }
  },
  {
    id: 'minimal-noir',
    name: 'Pure Monochrome',
    description: 'Crisp classic black on paper white with high readability',
    previewGradient: 'from-zinc-900 to-zinc-700',
    config: {
      shape: 'square',
      dotType: 'square',
      cornerSquareType: 'square',
      cornerDotType: 'square',
      dotsColorType: 'solid',
      dotsColor: '#09090b',
      dotsGradient: {
        type: 'linear',
        rotation: 0,
        color1: '#09090b',
        color2: '#27272a'
      },
      customCornersColor: false,
      cornerSquareColor: '#09090b',
      cornerDotColor: '#09090b',
      bgColorType: 'solid',
      bgColor: '#ffffff',
      hideBackgroundDots: true,
      logoBackground: 'square',
      errorCorrection: 'M',
      frameStyle: 'modern-card',
      frameText: 'SCAN TO CONNECT',
      frameColor: '#18181b',
      frameTextColor: '#ffffff'
    }
  },
  {
    id: 'ocean-sapphire',
    name: 'Ocean Sapphire',
    description: 'Pacific azure and deep marine royal blue',
    previewGradient: 'from-blue-400 to-indigo-600',
    config: {
      shape: 'square',
      dotType: 'extra-rounded',
      cornerSquareType: 'extra-rounded',
      cornerDotType: 'dot',
      dotsColorType: 'gradient',
      dotsColor: '#2563eb',
      dotsGradient: {
        type: 'linear',
        rotation: 60,
        color1: '#38bdf8',
        color2: '#1d4ed8'
      },
      customCornersColor: true,
      cornerSquareColor: '#1d4ed8',
      cornerDotColor: '#38bdf8',
      bgColorType: 'solid',
      bgColor: '#f8fafc',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'bottom-banner',
      frameText: 'SCAN TO OPEN',
      frameColor: '#1e40af',
      frameTextColor: '#ffffff'
    }
  },
  {
    id: 'lavender-haze',
    name: 'Lavender Dream',
    description: 'Aesthetic pastel violet and periwinkle glow',
    previewGradient: 'from-indigo-300 to-purple-500',
    config: {
      shape: 'square',
      dotType: 'rounded',
      cornerSquareType: 'extra-rounded',
      cornerDotType: 'dot',
      dotsColorType: 'gradient',
      dotsColor: '#8b5cf6',
      dotsGradient: {
        type: 'linear',
        rotation: 120,
        color1: '#c084fc',
        color2: '#6366f1'
      },
      customCornersColor: false,
      cornerSquareColor: '#7c3aed',
      cornerDotColor: '#a855f7',
      bgColorType: 'solid',
      bgColor: '#17132a',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'badge-pill',
      frameText: 'FOLLOW ME',
      frameColor: '#2e1065',
      frameTextColor: '#e9d5ff'
    }
  },
  {
    id: 'crimson-ruby',
    name: 'Ruby Fire',
    description: 'Bold ruby red with vibrant golden highlights',
    previewGradient: 'from-red-500 to-amber-500',
    config: {
      shape: 'square',
      dotType: 'classy',
      cornerSquareType: 'extra-rounded',
      cornerDotType: 'square',
      dotsColorType: 'gradient',
      dotsColor: '#dc2626',
      dotsGradient: {
        type: 'linear',
        rotation: 45,
        color1: '#ef4444',
        color2: '#f59e0b'
      },
      customCornersColor: true,
      cornerSquareColor: '#dc2626',
      cornerDotColor: '#f59e0b',
      bgColorType: 'solid',
      bgColor: '#ffffff',
      hideBackgroundDots: true,
      logoBackground: 'circle',
      errorCorrection: 'Q',
      frameStyle: 'top-badge',
      frameText: 'SPECIAL OFFER',
      frameColor: '#dc2626',
      frameTextColor: '#ffffff'
    }
  }
];
