import React, { useState, useEffect } from 'react';
import { 
  Link as LinkIcon, 
  Shapes, 
  Palette, 
  Image as ImageIcon, 
  LayoutTemplate, 
  Sparkles
} from 'lucide-react';

// Types & Data
import { QRConfig, QRHistoryItem } from './types/qr';
import { initialQRData, QRDataState, generateQRPayload } from './utils/qrPayload';
import { defaultQRConfig } from './data/defaultConfig';
import { QRPreset } from './data/presets';

// Components
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { QRPreview } from './components/QRPreview';
import { ContentTab } from './components/tabs/ContentTab';
import { ShapeStyleTab } from './components/tabs/ShapeStyleTab';
import { ColorsTab } from './components/tabs/ColorsTab';
import { LogoTab } from './components/tabs/LogoTab';
import { FrameTab } from './components/tabs/FrameTab';
import { PresetsTab } from './components/tabs/PresetsTab';
import { ScanTesterModal } from './components/ScanTesterModal';
import { HistoryDrawer } from './components/HistoryDrawer';

type ActiveTab = 'content' | 'shapes' | 'colors' | 'logo' | 'frame' | 'presets';

export const App: React.FC = () => {
  // State
  const [dataState, setDataState] = useState<QRDataState>(initialQRData);
  const [config, setConfig] = useState<QRConfig>(defaultQRConfig);
  const [activeTab, setActiveTab] = useState<ActiveTab>('content');

  // Modals & Drawers
  const [showSimulator, setShowSimulator] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<QRHistoryItem[]>([]);

  // Generated Payload & Summary
  const { payload, displaySummary } = generateQRPayload(dataState);

  // Load history from localStorage on initial render
  useEffect(() => {
    try {
      const saved = localStorage.getItem('qr_studio_history');
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error('Failed to load history', e);
    }
  }, []);

  // Save history item when user downloads or exports
  const handleSaveToHistory = (previewUrl: string) => {
    const newItem: QRHistoryItem = {
      id: Date.now().toString(),
      title: displaySummary,
      type: dataState.type,
      rawData: payload,
      config: { ...config },
      previewUrl,
      createdAt: Date.now()
    };

    setHistory((prev) => {
      const updated = [newItem, ...prev.slice(0, 19)];
      try {
        localStorage.setItem('qr_studio_history', JSON.stringify(updated));
      } catch (e) {
        console.error('Storage full or error', e);
      }
      return updated;
    });
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem('qr_studio_history');
    } catch (e) {
      console.error(e);
    }
  };

  const handleLoadHistoryItem = (savedConfig: QRConfig, savedRawData: string) => {
    setConfig(savedConfig);
    setDataState((prev) => ({
      ...prev,
      type: 'url',
      url: savedRawData
    }));
  };

  // Reset to Defaults
  const handleReset = () => {
    if (confirm('Reset all styling and content to defaults?')) {
      setConfig(defaultQRConfig);
      setDataState(initialQRData);
    }
  };

  // Apply Designer Preset
  const handleApplyPreset = (preset: QRPreset) => {
    setConfig((prev) => ({
      ...prev,
      ...preset.config
    }));
  };

  const tabs: { id: ActiveTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }[] = [
    { id: 'content', label: '1. Content & Link', icon: LinkIcon },
    { id: 'shapes', label: '2. Shapes & Eyes', icon: Shapes },
    { id: 'colors', label: '3. Colors & BG', icon: Palette },
    { id: 'logo', label: '4. Center Logo', icon: ImageIcon, badge: config.logo ? 'Active' : undefined },
    { id: 'frame', label: '5. Frame & CTA', icon: LayoutTemplate, badge: config.frameStyle !== 'none' ? 'Frame' : undefined },
    { id: 'presets', label: '✨ Themes', icon: Sparkles },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Navigation Header */}
      <Header
        historyCount={history.length}
        onOpenHistory={() => setShowHistory(true)}
        onOpenSimulator={() => setShowSimulator(true)}
        onReset={handleReset}
        onQuickPreset={() => setActiveTab('presets')}
      />

      {/* Main Studio Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Banner / Guide info */}
        <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-slate-900 border border-indigo-500/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg shadow-indigo-950/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-100">
                Design & Download Custom QR Codes in Pure PNG, SVG & High-Res
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Customize dot shapes, corner eye squares, background gradients, center logo, and download pure image without watermarks.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('presets')}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 hover:text-white border border-indigo-500/40 transition whitespace-nowrap"
            >
              Browse 8+ Themes
            </button>
            <button
              type="button"
              onClick={() => setShowSimulator(true)}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition whitespace-nowrap"
            >
              Test Scan Live
            </button>
          </div>
        </div>

        {/* 2-Column Responsive Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Tab Controls (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            {/* Tab Navigation Pill Bar */}
            <div className="flex items-center gap-1.5 p-1.5 bg-slate-900/90 border border-slate-800/80 rounded-2xl overflow-x-auto scrollbar-none shadow-inner">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap relative ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-indigo-400'}`} />
                    <span>{tab.label}</span>
                    {tab.badge && (
                      <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive ? 'bg-indigo-900 text-indigo-200' : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {tab.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Active Tab Content Panel */}
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-3xl p-6 shadow-2xl backdrop-blur-sm min-h-[460px]">
              {activeTab === 'content' && (
                <ContentTab
                  dataState={dataState}
                  onChange={(updates) => setDataState((prev) => ({ ...prev, ...updates }))}
                />
              )}

              {activeTab === 'shapes' && (
                <ShapeStyleTab
                  config={config}
                  onChange={(updates) => setConfig((prev) => ({ ...prev, ...updates }))}
                />
              )}

              {activeTab === 'colors' && (
                <ColorsTab
                  config={config}
                  onChange={(updates) => setConfig((prev) => ({ ...prev, ...updates }))}
                />
              )}

              {activeTab === 'logo' && (
                <LogoTab
                  config={config}
                  onChange={(updates) => setConfig((prev) => ({ ...prev, ...updates }))}
                />
              )}

              {activeTab === 'frame' && (
                <FrameTab
                  config={config}
                  onChange={(updates) => setConfig((prev) => ({ ...prev, ...updates }))}
                />
              )}

              {activeTab === 'presets' && (
                <PresetsTab
                  config={config}
                  onApplyPreset={handleApplyPreset}
                />
              )}
            </div>
          </div>

          {/* Right Column: Sticky Live QR Preview & Actions (5 cols) */}
          <div className="lg:col-span-5 sticky top-24">
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-3xl p-5 shadow-2xl backdrop-blur-sm">
              <QRPreview
                payload={payload}
                summary={displaySummary}
                config={config}
                onOpenSimulator={() => setShowSimulator(true)}
                onSaveToHistory={handleSaveToHistory}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Simulator Modal */}
      <ScanTesterModal
        isOpen={showSimulator}
        onClose={() => setShowSimulator(false)}
        type={dataState.type}
        payload={payload}
        summary={displaySummary}
      />

      {/* History Drawer */}
      <HistoryDrawer
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        history={history}
        onLoadItem={handleLoadHistoryItem}
        onClearHistory={handleClearHistory}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default App;
