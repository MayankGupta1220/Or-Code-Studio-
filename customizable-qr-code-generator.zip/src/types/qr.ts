export type QRDataType = 
  | 'url' 
  | 'text' 
  | 'wifi' 
  | 'vcard' 
  | 'email' 
  | 'phone' 
  | 'sms' 
  | 'whatsapp' 
  | 'upi' 
  | 'social';

export type QRShape = 'square' | 'circle';
export type DotType = 'square' | 'dots' | 'rounded' | 'classy' | 'classy-rounded' | 'extra-rounded';
export type CornerSquareType = 'square' | 'dot' | 'extra-rounded';
export type CornerDotType = 'square' | 'dot';

export type GradientType = 'linear' | 'radial';

export interface ColorGradient {
  type: GradientType;
  rotation: number; // in degrees
  color1: string;
  color2: string;
}

export type FrameStyle = 
  | 'none' 
  | 'bottom-banner' 
  | 'top-badge' 
  | 'polaroid' 
  | 'modern-card' 
  | 'badge-pill';

export interface QRConfig {
  // Shape & Pattern
  shape: QRShape;
  dotType: DotType;
  cornerSquareType: CornerSquareType;
  cornerDotType: CornerDotType;

  // Dots Color
  dotsColorType: 'solid' | 'gradient';
  dotsColor: string;
  dotsGradient: ColorGradient;

  // Corners Color Customization
  customCornersColor: boolean;
  cornerSquareColor: string;
  cornerDotColor: string;

  // Background
  bgColorType: 'solid' | 'gradient' | 'transparent';
  bgColor: string;
  bgGradient: ColorGradient;

  // Logo
  logo: string | null;
  logoName?: string;
  logoSize: number; // 0.15 - 0.45
  logoMargin: number; // 0 - 20
  hideBackgroundDots: boolean;
  logoBackground: 'none' | 'circle' | 'square';

  // Quality & Error Correction
  errorCorrection: 'L' | 'M' | 'Q' | 'H';
  margin: number; // QR quiet zone margin

  // Frame / Badge
  frameStyle: FrameStyle;
  frameText: string;
  frameColor: string;
  frameTextColor: string;
}

export interface QRHistoryItem {
  id: string;
  title: string;
  type: QRDataType;
  rawData: string;
  config: QRConfig;
  previewUrl: string;
  createdAt: number;
}
