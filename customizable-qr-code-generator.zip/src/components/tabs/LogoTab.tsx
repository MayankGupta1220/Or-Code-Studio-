import React, { useRef } from 'react';
import { QRConfig } from '../../types/qr';
import { PRESET_LOGOS } from '../../data/logoPresets';
import { Upload, X, ShieldAlert, Image as ImageIcon } from 'lucide-react';

interface LogoTabProps {
  config: QRConfig;
  onChange: (updates: Partial<QRConfig>) => void;
}

export const LogoTab: React.FC<LogoTabProps> = ({
  config,
  onChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUri = event.target?.result as string;
      onChange({
        logo: dataUri,
        logoName: file.name,
        errorCorrection: 'Q', // Automatically ensure high error correction for logos
        hideBackgroundDots: true
      });
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUri = event.target?.result as string;
      onChange({
        logo: dataUri,
        logoName: file.name,
        errorCorrection: 'Q',
        hideBackgroundDots: true
      });
    };
    reader.readAsDataURL(file);
  };

  const removeLogo = () => {
    onChange({ logo: null, logoName: undefined });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-6">
      {/* Active Logo Status & Preview */}
      {config.logo ? (
        <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/10 p-1.5 flex items-center justify-center border border-white/20">
              <img
                src={config.logo}
                alt="Selected logo"
                className="max-w-full max-h-full object-contain"
              />
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-100 flex items-center gap-2">
                <span>{config.logoName || 'Center Logo'}</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  Active
                </span>
              </div>
              <div className="text-xs text-slate-400">
                Centered inside QR with clear padding
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={removeLogo}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 text-xs font-medium transition"
          >
            <X className="w-3.5 h-3.5" />
            Remove
          </button>
        </div>
      ) : null}

      {/* Upload Custom Logo Area */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
          Upload Custom Logo (PNG, SVG, JPG)
        </label>
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className="p-6 rounded-2xl border-2 border-dashed border-slate-700/80 hover:border-indigo-500 bg-slate-900/40 hover:bg-slate-900/80 cursor-pointer transition text-center group"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />
          <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 group-hover:bg-indigo-600/20 group-hover:text-indigo-400 flex items-center justify-center text-slate-400 transition mb-3">
            <Upload className="w-5 h-5" />
          </div>
          <div className="text-sm font-medium text-slate-200">
            Click to upload your brand logo or drag & drop
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Square PNG with transparent background recommended
          </p>
        </div>
      </div>

      {/* Preset Brand Logos */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
          Or Choose from Popular Presets
        </label>
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2">
          {PRESET_LOGOS.map((item) => {
            const isSelected = config.logo === item.dataUri;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() =>
                  onChange({
                    logo: item.dataUri,
                    logoName: item.name,
                    errorCorrection: 'Q',
                    hideBackgroundDots: true
                  })
                }
                className={`flex flex-col items-center justify-center p-2 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-md ring-1 ring-indigo-400'
                    : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/80'
                }`}
              >
                <div className="w-8 h-8 mb-1 flex items-center justify-center">
                  <img
                    src={item.dataUri}
                    alt={item.name}
                    className="w-7 h-7 object-contain"
                  />
                </div>
                <span className="text-[11px] truncate w-full text-center font-medium">
                  {item.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Logo Tuning Controls */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
          <ImageIcon className="w-4 h-4 text-indigo-400" /> Logo Fine-Tuning
        </h4>

        {/* Size Slider */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-medium text-slate-300">Logo Size</span>
            <span className="font-mono text-indigo-400">
              {Math.round(config.logoSize * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0.15}
            max={0.45}
            step={0.02}
            value={config.logoSize}
            onChange={(e) => onChange({ logoSize: Number(e.target.value) })}
            className="w-full accent-indigo-500 bg-slate-800 h-2 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1">
            <span>Subtle (15%)</span>
            <span>Balanced (35%)</span>
            <span>Prominent (45%)</span>
          </div>
        </div>

        {/* Margin Slider */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-medium text-slate-300">Clear Space (Padding)</span>
            <span className="font-mono text-indigo-400">{config.logoMargin}px</span>
          </div>
          <input
            type="range"
            min={0}
            max={18}
            step={1}
            value={config.logoMargin}
            onChange={(e) => onChange({ logoMargin: Number(e.target.value) })}
            className="w-full accent-indigo-500 bg-slate-800 h-2 rounded-lg cursor-pointer"
          />
        </div>

        {/* Hide Background Dots Switch */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
          <div>
            <span className="text-xs font-medium text-slate-200 block">
              Clear Background Dots Behind Logo
            </span>
            <span className="text-[11px] text-slate-400">
              Prevents dots from showing through or cluttering your icon
            </span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={config.hideBackgroundDots}
              onChange={(e) => onChange({ hideBackgroundDots: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>

        {/* Scannability Notice */}
        {config.logo && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-2 text-xs text-amber-300">
            <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-amber-200">High Scannability Active</p>
              <p className="text-[11px] text-amber-300/80 mt-0.5">
                We've automatically enabled Quartile Error Correction (25%) so smartphones can scan your QR code instantly, even with the center logo.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
