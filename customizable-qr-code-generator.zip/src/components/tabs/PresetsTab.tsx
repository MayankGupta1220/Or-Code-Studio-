import React from 'react';
import { QRConfig } from '../../types/qr';
import { QR_PRESETS, QRPreset } from '../../data/presets';
import { Sparkles, Check } from 'lucide-react';

interface PresetsTabProps {
  config: QRConfig;
  onApplyPreset: (preset: QRPreset) => void;
}

export const PresetsTab: React.FC<PresetsTabProps> = ({
  config,
  onApplyPreset,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
          Curated Designer Themes (1-Click Apply)
        </label>
        <span className="text-[11px] text-slate-500">
          Keeps your link intact
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {QR_PRESETS.map((preset) => {
          const isCurrentTheme =
            config.dotsColor === preset.config.dotsColor &&
            config.dotType === preset.config.dotType;

          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => onApplyPreset(preset)}
              className={`p-3.5 rounded-2xl border text-left transition-all flex items-start gap-3.5 group relative overflow-hidden ${
                isCurrentTheme
                  ? 'bg-indigo-950/40 border-indigo-500/80 ring-2 ring-indigo-500/50 shadow-lg shadow-indigo-900/30'
                  : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-800/80'
              }`}
            >
              {/* Visual preview chip with gradient */}
              <div
                className={`w-12 h-12 rounded-xl flex-shrink-0 bg-gradient-to-br ${preset.previewGradient} p-1 flex items-center justify-center shadow-md`}
              >
                <div className="w-8 h-8 rounded-lg bg-slate-950/70 flex items-center justify-center">
                  <div className="w-3 h-3 rounded-sm bg-white" />
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-100 group-hover:text-white truncate">
                    {preset.name}
                  </span>
                  {preset.badge && (
                    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {preset.badge}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {preset.description}
                </p>
              </div>

              {isCurrentTheme && (
                <div className="w-5 h-5 rounded-full bg-indigo-500 flex items-center justify-center text-white">
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </div>
              )}
            </button>
          );
        })}
      </div>

      <div className="p-3 bg-slate-900/40 rounded-xl border border-slate-800 flex items-center gap-2 text-xs text-slate-400">
        <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
        <span>
          Tip: You can start with any theme and fine-tune its colors, corners, or logo in the other tabs!
        </span>
      </div>
    </div>
  );
};
