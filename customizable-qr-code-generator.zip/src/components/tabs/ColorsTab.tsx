import React from 'react';
import { QRConfig } from '../../types/qr';
import { Palette, Sparkles, Sliders } from 'lucide-react';

interface ColorsTabProps {
  config: QRConfig;
  onChange: (updates: Partial<QRConfig>) => void;
}

const COLOR_SWATCHES = [
  { name: 'Monochrome Black', color: '#000000' },
  { name: 'Pure White', color: '#ffffff' },
  { name: 'Indigo Electric', color: '#6366f1' },
  { name: 'Cyber Cyan', color: '#06b6d4' },
  { name: 'Emerald Green', color: '#10b981' },
  { name: 'Sunset Rose', color: '#f43f5e' },
  { name: 'Amber Gold', color: '#f59e0b' },
  { name: 'Deep Purple', color: '#8b5cf6' },
  { name: 'Midnight Slate', color: '#0f172a' },
  { name: 'Navy Blue', color: '#1e3a8a' },
];

const GRADIENT_PRESETS = [
  { name: 'Indigo Violet', c1: '#6366f1', c2: '#a855f7', rot: 45 },
  { name: 'Neon Cyber', c1: '#06b6d4', c2: '#ec4899', rot: 90 },
  { name: 'Sunset Glow', c1: '#f97316', c2: '#e11d48', rot: 135 },
  { name: 'Emerald Forest', c1: '#34d399', c2: '#059669', rot: 45 },
  { name: 'Golden Champagne', c1: '#fde68a', c2: '#d97706', rot: 60 },
  { name: 'Ocean Depths', c1: '#38bdf8', c2: '#1e40af', rot: 120 },
];

export const ColorsTab: React.FC<ColorsTabProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* QR Code Dots Color Section */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-slate-200">QR Code Dots Color</h3>
          </div>
          {/* Mode Switch: Solid vs Gradient */}
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => onChange({ dotsColorType: 'solid' })}
              className={`px-3 py-1 rounded-lg font-medium transition ${
                config.dotsColorType === 'solid'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Solid
            </button>
            <button
              type="button"
              onClick={() => onChange({ dotsColorType: 'gradient' })}
              className={`px-3 py-1 rounded-lg font-medium transition ${
                config.dotsColorType === 'gradient'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Gradient
            </button>
          </div>
        </div>

        {/* Solid Color Options */}
        {config.dotsColorType === 'solid' && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={config.dotsColor}
                onChange={(e) => onChange({ dotsColor: e.target.value })}
                className="w-12 h-10 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-1"
              />
              <div className="flex-1">
                <input
                  type="text"
                  value={config.dotsColor}
                  onChange={(e) => onChange({ dotsColor: e.target.value })}
                  placeholder="#6366f1"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Swatches */}
            <div>
              <span className="text-[11px] text-slate-400 block mb-1.5">Preset Swatches</span>
              <div className="flex flex-wrap gap-2">
                {COLOR_SWATCHES.map((swatch) => (
                  <button
                    key={swatch.color}
                    type="button"
                    title={swatch.name}
                    onClick={() => onChange({ dotsColor: swatch.color })}
                    className={`w-7 h-7 rounded-lg border-2 transition transform hover:scale-110 ${
                      config.dotsColor.toLowerCase() === swatch.color.toLowerCase()
                        ? 'border-indigo-400 ring-2 ring-indigo-500/50 scale-105'
                        : 'border-slate-700'
                    }`}
                    style={{ backgroundColor: swatch.color }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Gradient Options */}
        {config.dotsColorType === 'gradient' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Color 1 (Start)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.dotsGradient.color1}
                    onChange={(e) =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, color1: e.target.value }
                      })
                    }
                    className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={config.dotsGradient.color1}
                    onChange={(e) =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, color1: e.target.value }
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Color 2 (End)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.dotsGradient.color2}
                    onChange={(e) =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, color2: e.target.value }
                      })
                    }
                    className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={config.dotsGradient.color2}
                    onChange={(e) =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, color2: e.target.value }
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                  />
                </div>
              </div>
            </div>

            {/* Gradient Type & Angle */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Gradient Style</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, type: 'linear' }
                      })
                    }
                    className={`flex-1 py-1.5 text-xs font-medium rounded-lg border transition ${
                      config.dotsGradient.type === 'linear'
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    Linear
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, type: 'radial' }
                      })
                    }
                    className={`flex-1 py-1.5 text-xs font-medium rounded-lg border transition ${
                      config.dotsGradient.type === 'radial'
                        ? 'bg-indigo-600 border-indigo-500 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-300'
                    }`}
                  >
                    Radial
                  </button>
                </div>
              </div>

              {config.dotsGradient.type === 'linear' && (
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium text-slate-300">Angle Rotation</span>
                    <span className="font-mono text-indigo-400">{config.dotsGradient.rotation}°</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={360}
                    step={15}
                    value={config.dotsGradient.rotation}
                    onChange={(e) =>
                      onChange({
                        dotsGradient: { ...config.dotsGradient, rotation: Number(e.target.value) }
                      })
                    }
                    className="w-full accent-indigo-500 bg-slate-800 h-2 rounded-lg cursor-pointer mt-1"
                  />
                </div>
              )}
            </div>

            {/* Gradient Presets */}
            <div>
              <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-2">
                <Sparkles className="w-3 h-3 text-indigo-400" /> Designer Gradients
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {GRADIENT_PRESETS.map((preset) => (
                  <button
                    key={preset.name}
                    type="button"
                    onClick={() =>
                      onChange({
                        dotsColorType: 'gradient',
                        dotsGradient: {
                          type: 'linear',
                          rotation: preset.rot,
                          color1: preset.c1,
                          color2: preset.c2
                        }
                      })
                    }
                    className="flex items-center gap-2 p-1.5 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-950/60 transition text-left"
                  >
                    <div
                      className="w-5 h-5 rounded-md flex-shrink-0 shadow-sm"
                      style={{
                        background: `linear-gradient(${preset.rot}deg, ${preset.c1}, ${preset.c2})`
                      }}
                    />
                    <span className="text-xs text-slate-300 truncate">{preset.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Eye / Corner Specific Colors */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">Corner Eyes Custom Colors</h3>
            <p className="text-xs text-slate-400">Color outer square and inner pupil independently</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={config.customCornersColor}
              onChange={(e) => onChange({ customCornersColor: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>

        {config.customCornersColor ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Outer Corner Frame Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={config.cornerSquareColor}
                  onChange={(e) => onChange({ cornerSquareColor: e.target.value })}
                  className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={config.cornerSquareColor}
                  onChange={(e) => onChange({ cornerSquareColor: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Inner Eye Dot Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={config.cornerDotColor}
                  onChange={(e) => onChange({ cornerDotColor: e.target.value })}
                  className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={config.cornerDotColor}
                  onChange={(e) => onChange({ cornerDotColor: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="text-xs text-slate-500 italic bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/50">
            Corner eyes currently match the QR code body dots color automatically.
          </div>
        )}
      </div>

      {/* Background Section */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-200">Background Styling</h3>
          </div>
          {/* Solid vs Gradient vs Transparent */}
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            {(['solid', 'gradient', 'transparent'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => onChange({ bgColorType: mode })}
                className={`px-2.5 py-1 rounded-lg font-medium capitalize transition ${
                  config.bgColorType === mode
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {config.bgColorType === 'solid' && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={config.bgColor}
                onChange={(e) => onChange({ bgColor: e.target.value })}
                className="w-12 h-10 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-1"
              />
              <div className="flex-1">
                <input
                  type="text"
                  value={config.bgColor}
                  onChange={(e) => onChange({ bgColor: e.target.value })}
                  placeholder="#ffffff"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Quick Backgrounds */}
            <div>
              <span className="text-[11px] text-slate-400 block mb-1.5">Popular Backgrounds</span>
              <div className="flex flex-wrap gap-2">
                {[
                  { name: 'Pure White', color: '#ffffff' },
                  { name: 'Warm Cream', color: '#fffbeb' },
                  { name: 'Cool Slate', color: '#f8fafc' },
                  { name: 'Deep Obsidian', color: '#090d16' },
                  { name: 'Dark Slate', color: '#0f172a' },
                  { name: 'Night Zinc', color: '#18181b' },
                ].map((bg) => (
                  <button
                    key={bg.color}
                    type="button"
                    onClick={() => onChange({ bgColor: bg.color })}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-2 transition ${
                      config.bgColor.toLowerCase() === bg.color.toLowerCase()
                        ? 'border-indigo-400 bg-slate-800 text-white'
                        : 'border-slate-800 bg-slate-950/80 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="w-3.5 h-3.5 rounded-full border border-slate-600" style={{ backgroundColor: bg.color }} />
                    {bg.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {config.bgColorType === 'gradient' && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">BG Start Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.bgGradient.color1}
                    onChange={(e) =>
                      onChange({
                        bgGradient: { ...config.bgGradient, color1: e.target.value }
                      })
                    }
                    className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={config.bgGradient.color1}
                    onChange={(e) =>
                      onChange({
                        bgGradient: { ...config.bgGradient, color1: e.target.value }
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">BG End Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={config.bgGradient.color2}
                    onChange={(e) =>
                      onChange({
                        bgGradient: { ...config.bgGradient, color2: e.target.value }
                      })
                    }
                    className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                  />
                  <input
                    type="text"
                    value={config.bgGradient.color2}
                    onChange={(e) =>
                      onChange({
                        bgGradient: { ...config.bgGradient, color2: e.target.value }
                      })
                    }
                    className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {config.bgColorType === 'transparent' && (
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs text-slate-400">
            <p className="font-medium text-slate-300 mb-1">Transparent PNG / SVG Background</p>
            The QR code will export with a transparent background, perfect for overlaying onto brochures, posters, packaging, or websites.
          </div>
        )}
      </div>
    </div>
  );
};
