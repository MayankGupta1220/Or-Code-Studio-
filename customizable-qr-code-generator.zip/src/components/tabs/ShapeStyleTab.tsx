import React from 'react';
import { QRConfig, QRShape, DotType, CornerSquareType, CornerDotType } from '../../types/qr';
import { ShieldCheck, Info } from 'lucide-react';

interface ShapeStyleTabProps {
  config: QRConfig;
  onChange: (updates: Partial<QRConfig>) => void;
}

export const ShapeStyleTab: React.FC<ShapeStyleTabProps> = ({
  config,
  onChange,
}) => {
  const shapes: { id: QRShape; label: string; desc: string }[] = [
    { id: 'square', label: 'Standard Square', desc: 'Classic rectangular bounds' },
    { id: 'circle', label: 'Circular Shape', desc: 'Modern circular silhouette' },
  ];

  const dotPatterns: { id: DotType; label: string; previewClass: string }[] = [
    { id: 'square', label: 'Classic Square', previewClass: 'rounded-none' },
    { id: 'rounded', label: 'Soft Rounded', previewClass: 'rounded-[3px]' },
    { id: 'dots', label: 'Clean Dots', previewClass: 'rounded-full' },
    { id: 'classy', label: 'Classy Diamond', previewClass: 'rotate-45 scale-90' },
    { id: 'classy-rounded', label: 'Classy Rounded', previewClass: 'rotate-45 scale-90 rounded-[2px]' },
    { id: 'extra-rounded', label: 'Liquid Pill', previewClass: 'rounded-lg' },
  ];

  const cornerSquares: { id: CornerSquareType; label: string; borderClass: string }[] = [
    { id: 'square', label: 'Sharp Square', borderClass: 'rounded-none' },
    { id: 'extra-rounded', label: 'Smooth Rounded', borderClass: 'rounded-lg' },
    { id: 'dot', label: 'Circular Eye', borderClass: 'rounded-full' },
  ];

  const cornerDots: { id: CornerDotType; label: string; shapeClass: string }[] = [
    { id: 'square', label: 'Square Pupil', shapeClass: 'rounded-none' },
    { id: 'dot', label: 'Circle Pupil', shapeClass: 'rounded-full' },
  ];

  return (
    <div className="space-y-6">
      {/* Overall QR Shape */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
          Overall QR Code Silhouette
        </label>
        <div className="grid grid-cols-2 gap-3">
          {shapes.map((s) => {
            const isSelected = config.shape === s.id;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => onChange({ shape: s.id })}
                className={`flex items-center gap-3.5 p-3.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-600/10'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div
                  className={`w-9 h-9 flex items-center justify-center border-2 ${
                    s.id === 'circle' ? 'rounded-full' : 'rounded-lg'
                  } ${isSelected ? 'border-indigo-400 bg-indigo-500/30' : 'border-slate-600 bg-slate-800'}`}
                >
                  <div className={`w-3 h-3 ${s.id === 'circle' ? 'rounded-full' : 'rounded-sm'} ${isSelected ? 'bg-indigo-300' : 'bg-slate-400'}`} />
                </div>
                <div>
                  <div className="text-sm font-semibold">{s.label}</div>
                  <div className="text-[11px] text-slate-400">{s.desc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Body Dots Pattern */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
          QR Code Dot Pattern (Body)
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {dotPatterns.map((dp) => {
            const isSelected = config.dotType === dp.id;
            return (
              <button
                key={dp.id}
                type="button"
                onClick={() => onChange({ dotType: dp.id })}
                className={`flex flex-col items-center p-3 rounded-xl border transition-all text-center ${
                  isSelected
                    ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md shadow-indigo-600/20'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                {/* Visual miniature representation */}
                <div className="w-8 h-8 mb-2 flex items-center justify-center">
                  <div className="grid grid-cols-2 gap-1">
                    <div className={`w-2.5 h-2.5 bg-indigo-400 ${dp.previewClass}`} />
                    <div className={`w-2.5 h-2.5 bg-indigo-400 ${dp.previewClass}`} />
                    <div className={`w-2.5 h-2.5 bg-indigo-400 ${dp.previewClass}`} />
                    <div className={`w-2.5 h-2.5 bg-indigo-400 ${dp.previewClass}`} />
                  </div>
                </div>
                <span className="text-xs font-semibold">{dp.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Eye / Corner Styling Section */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span>Corner Eyes Shape (Circus ke Squires)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Customize the 3 position detection squares in the corners
          </p>
        </div>

        {/* Outer Corner Frame */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-2">
            Outer Eye Frame Style
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            {cornerSquares.map((cs) => {
              const isSelected = config.cornerSquareType === cs.id;
              return (
                <button
                  key={cs.id}
                  type="button"
                  onClick={() => onChange({ cornerSquareType: cs.id })}
                  className={`flex flex-col items-center p-2.5 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-indigo-600/25 border-indigo-500 text-white ring-1 ring-indigo-400'
                      : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className={`w-6 h-6 border-2 border-indigo-400 mb-1.5 flex items-center justify-center ${cs.borderClass}`}>
                    <div className="w-2 h-2 bg-indigo-400 rounded-sm" />
                  </div>
                  <span className="text-xs font-medium">{cs.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Inner Corner Dot */}
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-2">
            Inner Eye Pupil Style
          </label>
          <div className="grid grid-cols-2 gap-2.5">
            {cornerDots.map((cd) => {
              const isSelected = config.cornerDotType === cd.id;
              return (
                <button
                  key={cd.id}
                  type="button"
                  onClick={() => onChange({ cornerDotType: cd.id })}
                  className={`flex items-center justify-center gap-2.5 p-2.5 rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-indigo-600/25 border-indigo-500 text-white ring-1 ring-indigo-400'
                      : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="w-5 h-5 border border-indigo-400/80 rounded-md flex items-center justify-center">
                    <div className={`w-2.5 h-2.5 bg-indigo-400 ${cd.shapeClass}`} />
                  </div>
                  <span className="text-xs font-medium">{cd.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Advanced Geometry & Error Correction */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        {/* Margin Slider */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-slate-300">Quiet Zone (Margin)</span>
            <span className="font-mono text-indigo-400">{config.margin}px</span>
          </div>
          <input
            type="range"
            min={0}
            max={36}
            step={2}
            value={config.margin}
            onChange={(e) => onChange({ margin: Number(e.target.value) })}
            className="w-full accent-indigo-500 bg-slate-800 h-2 rounded-lg cursor-pointer"
          />
        </div>

        {/* Error Correction Level */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Error Correction Level
            </span>
            <span className="text-[11px] text-slate-400">Higher = safer with logos</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[
              { id: 'L', label: 'L - Low', pct: '7%' },
              { id: 'M', label: 'M - Med', pct: '15%' },
              { id: 'Q', label: 'Q - High', pct: '25%' },
              { id: 'H', label: 'H - Max', pct: '30%' },
            ].map((ec) => (
              <button
                key={ec.id}
                type="button"
                onClick={() => onChange({ errorCorrection: ec.id as any })}
                className={`py-2 px-1 text-center rounded-xl border text-xs font-semibold transition ${
                  config.errorCorrection === ec.id
                    ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div>{ec.label}</div>
                <div className="text-[10px] opacity-75">{ec.pct} recovery</div>
              </button>
            ))}
          </div>
          <p className="text-[11px] text-slate-500 mt-1.5 flex items-center gap-1">
            <Info className="w-3.5 h-3.5 flex-shrink-0 text-slate-400" />
            Allows the QR code to be scanned even if part of it is covered or damaged.
          </p>
        </div>
      </div>
    </div>
  );
};
