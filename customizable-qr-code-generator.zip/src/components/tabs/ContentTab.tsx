import React from 'react';
import { 
  Link, 
  FileText, 
  Wifi, 
  UserCheck, 
  Mail, 
  Phone, 
  MessageSquare, 
  MessageCircle, 
  CreditCard, 
  Share2,
  Sparkles
} from 'lucide-react';
import { QRDataType } from '../../types/qr';
import { QRDataState } from '../../utils/qrPayload';

interface ContentTabProps {
  dataState: QRDataState;
  onChange: (updates: Partial<QRDataState>) => void;
  onSetPresetData?: (preset: Partial<QRDataState>) => void;
}

const DATA_TYPES: { id: QRDataType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'url', label: 'Website / Link', icon: Link },
  { id: 'wifi', label: 'Wi-Fi Network', icon: Wifi },
  { id: 'text', label: 'Plain Text', icon: FileText },
  { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle },
  { id: 'vcard', label: 'Contact / vCard', icon: UserCheck },
  { id: 'email', label: 'Email', icon: Mail },
  { id: 'phone', label: 'Call Phone', icon: Phone },
  { id: 'sms', label: 'SMS Message', icon: MessageSquare },
  { id: 'upi', label: 'UPI / Payment', icon: CreditCard },
  { id: 'social', label: 'Social Profile', icon: Share2 },
];

export const ContentTab: React.FC<ContentTabProps> = ({
  dataState,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Type Selector Grid */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
          Select Content Type
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
          {DATA_TYPES.map((item) => {
            const Icon = item.icon;
            const isSelected = dataState.type === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onChange({ type: item.id })}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 ring-2 ring-indigo-400'
                    : 'bg-slate-900/60 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700'
                }`}
              >
                <Icon className={`w-4 h-4 mb-1.5 ${isSelected ? 'text-white' : 'text-indigo-400'}`} />
                <span className="truncate w-full text-center">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Dynamic Content Inputs */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-inner">
        {/* URL Type */}
        {dataState.type === 'url' && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Target Website URL
                </label>
                <span className="text-[11px] text-slate-500">Auto-prefixes https://</span>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Link className="w-4 h-4" />
                </div>
                <input
                  type="url"
                  placeholder="https://yourwebsite.com or www.google.com"
                  value={dataState.url}
                  onChange={(e) => onChange({ url: e.target.value })}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                />
              </div>
            </div>

            {/* Quick URL samples */}
            <div className="pt-2 border-t border-slate-800/60">
              <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-2">
                <Sparkles className="w-3 h-3 text-amber-400" /> Quick Link Examples:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'Google Search', val: 'https://google.com' },
                  { label: 'YouTube Video', val: 'https://youtube.com' },
                  { label: 'Portfolio Link', val: 'https://myportfolio.design' },
                  { label: 'Instagram Profile', val: 'https://instagram.com/designer' },
                  { label: 'Digital Menu', val: 'https://menu.cafe.com' }
                ].map((sample) => (
                  <button
                    key={sample.label}
                    type="button"
                    onClick={() => onChange({ url: sample.val })}
                    className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-300 border border-slate-700/60 transition"
                  >
                    {sample.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Wi-Fi Type */}
        {dataState.type === 'wifi' && (
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Anyone who scans this QR code will automatically connect to your Wi-Fi without typing the password!
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Network SSID (Wi-Fi Name)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Home_5G_Fiber"
                  value={dataState.wifiSsid}
                  onChange={(e) => onChange({ wifiSsid: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Wi-Fi Password
                </label>
                <input
                  type="text"
                  placeholder="Enter Wi-Fi password"
                  value={dataState.wifiPassword}
                  onChange={(e) => onChange({ wifiPassword: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Encryption Type
                </label>
                <div className="flex gap-2">
                  {(['WPA', 'WEP', 'nopass'] as const).map((enc) => (
                    <button
                      key={enc}
                      type="button"
                      onClick={() => onChange({ wifiEncryption: enc })}
                      className={`px-3 py-1 text-xs rounded-lg font-medium transition ${
                        dataState.wifiEncryption === enc
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {enc === 'nopass' ? 'No Password' : enc}
                    </button>
                  ))}
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer mt-3 md:mt-0">
                <input
                  type="checkbox"
                  checked={dataState.wifiHidden}
                  onChange={(e) => onChange({ wifiHidden: e.target.checked })}
                  className="w-4 h-4 rounded text-indigo-600 bg-slate-950 border-slate-700 focus:ring-indigo-500"
                />
                <span className="text-xs text-slate-300">Hidden Network SSID</span>
              </label>
            </div>
          </div>
        )}

        {/* WhatsApp Type */}
        {dataState.type === 'whatsapp' && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                WhatsApp Phone Number (with Country Code)
              </label>
              <input
                type="text"
                placeholder="e.g. 919876543210 (include country code without +)"
                value={dataState.waNumber}
                onChange={(e) => onChange({ waNumber: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Pre-filled Message
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Hi! I saw your QR code and would like to chat."
                value={dataState.waMessage}
                onChange={(e) => onChange({ waMessage: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        )}

        {/* Plain Text */}
        {dataState.type === 'text' && (
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Plain Text or Secret Message
            </label>
            <textarea
              rows={4}
              placeholder="Type any message, note, code, or serial number here..."
              value={dataState.text}
              onChange={(e) => onChange({ text: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        )}

        {/* Contact / vCard */}
        {dataState.type === 'vcard' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">First Name</label>
                <input
                  type="text"
                  placeholder="Alex"
                  value={dataState.vcardFirstName}
                  onChange={(e) => onChange({ vcardFirstName: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Last Name</label>
                <input
                  type="text"
                  placeholder="Morgan"
                  value={dataState.vcardLastName}
                  onChange={(e) => onChange({ vcardLastName: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="+1 (555) 019-283"
                  value={dataState.vcardPhone}
                  onChange={(e) => onChange({ vcardPhone: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="alex@company.com"
                  value={dataState.vcardEmail}
                  onChange={(e) => onChange({ vcardEmail: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Company / Organization</label>
                <input
                  type="text"
                  placeholder="Design Lab Inc."
                  value={dataState.vcardOrg}
                  onChange={(e) => onChange({ vcardOrg: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Website URL</label>
                <input
                  type="url"
                  placeholder="https://alexmorgan.com"
                  value={dataState.vcardUrl}
                  onChange={(e) => onChange({ vcardUrl: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
            </div>
          </div>
        )}

        {/* Email */}
        {dataState.type === 'email' && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Recipient Email</label>
              <input
                type="email"
                placeholder="hello@studio.com"
                value={dataState.emailTo}
                onChange={(e) => onChange({ emailTo: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Subject</label>
              <input
                type="text"
                placeholder="Inquiry from QR Code"
                value={dataState.emailSubject}
                onChange={(e) => onChange({ emailSubject: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Pre-filled Body</label>
              <textarea
                rows={2}
                placeholder="Hello, I wanted to discuss..."
                value={dataState.emailBody}
                onChange={(e) => onChange({ emailBody: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
              />
            </div>
          </div>
        )}

        {/* Phone */}
        {dataState.type === 'phone' && (
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number to Dial</label>
            <input
              type="tel"
              placeholder="+1 (800) 555-0199"
              value={dataState.phoneNumber}
              onChange={(e) => onChange({ phoneNumber: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
            />
          </div>
        )}

        {/* SMS */}
        {dataState.type === 'sms' && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Phone Number</label>
              <input
                type="tel"
                placeholder="+1 555 123 4567"
                value={dataState.smsNumber}
                onChange={(e) => onChange({ smsNumber: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">SMS Message</label>
              <textarea
                rows={2}
                placeholder="Hi, please text me back."
                value={dataState.smsMessage}
                onChange={(e) => onChange({ smsMessage: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
              />
            </div>
          </div>
        )}

        {/* UPI / Payment */}
        {dataState.type === 'upi' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">UPI ID / VPA</label>
                <input
                  type="text"
                  placeholder="merchant@okhdfcbank"
                  value={dataState.upiVpa}
                  onChange={(e) => onChange({ upiVpa: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Payee Name</label>
                <input
                  type="text"
                  placeholder="Coffee Shop / Studio"
                  value={dataState.upiName}
                  onChange={(e) => onChange({ upiName: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Amount (Optional ₹)</label>
                <input
                  type="number"
                  placeholder="Leave empty for any amount"
                  value={dataState.upiAmount}
                  onChange={(e) => onChange({ upiAmount: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Transaction Note</label>
                <input
                  type="text"
                  placeholder="Order #491"
                  value={dataState.upiNote}
                  onChange={(e) => onChange({ upiNote: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
            </div>
          </div>
        )}

        {/* Social */}
        {dataState.type === 'social' && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Select Platform</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'instagram', label: 'Instagram' },
                  { id: 'twitter', label: 'X (Twitter)' },
                  { id: 'youtube', label: 'YouTube' },
                  { id: 'linkedin', label: 'LinkedIn' },
                  { id: 'github', label: 'GitHub' },
                  { id: 'spotify', label: 'Spotify' },
                  { id: 'telegram', label: 'Telegram' },
                  { id: 'facebook', label: 'Facebook' },
                ].map((plat) => (
                  <button
                    key={plat.id}
                    type="button"
                    onClick={() => onChange({ socialPlatform: plat.id as any })}
                    className={`px-2.5 py-1.5 text-xs font-medium rounded-lg capitalize transition ${
                      dataState.socialPlatform === plat.id
                        ? 'bg-indigo-600 text-white shadow'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {plat.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Profile Username or Handle
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500 text-sm">@</span>
                <input
                  type="text"
                  placeholder="username"
                  value={dataState.socialUsername}
                  onChange={(e) => onChange({ socialUsername: e.target.value })}
                  className="w-full pl-8 pr-4 py-2 bg-slate-950/80 border border-slate-700/80 rounded-xl text-sm text-slate-100"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
