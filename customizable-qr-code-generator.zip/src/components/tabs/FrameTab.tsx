import React from 'react';
import { QRConfig, FrameStyle } from '../../types/qr';
import { LayoutTemplate, Sparkles } from 'lucide-react';

interface FrameTabProps {
  config: QRConfig;
  onChange: (updates: Partial<QRConfig>) => void;
}

const FRAME_STYLES: { id: FrameStyle; label: string; desc: string }[] = [
  { id: 'none', label: 'Pure QR Only', desc: 'No frame, clean transparent or solid QR code' },
  { id: 'bottom-banner', label: 'Bottom Banner', desc: 'Bold banner bar at the bottom with CTA' },
  { id: 'top-badge', label: 'Top Header', desc: 'Header banner placed along the top edge' },
  { id: 'polaroid', label: 'Polaroid Style', desc: 'Classic white or colored card with bottom title' },
  { id: 'modern-card', label: 'Modern Card', desc: 'Rounded container with sleek CTA button pill' },
  { id: 'badge-pill', label: 'Badge Pill', desc: 'Floating rounded pill label with dark contrast' },
];

const CTA_PRESETS = [
  'SCAN ME',
  'SCAN TO VISIT',
  'CONNECT TO WIFI',
  'FOLLOW US',
  'VIEW MENU',
  'PAY NOW',
  'EXCLUSIVE ACCESS',
  'GET DISCOUNT',
  'CALL US',
  'SAVE CONTACT'
];

export const FrameTab: React.FC<FrameTabProps> = ({
  config,
  onChange,
}) => {
  return (
    <div className="space-y-6">
      {/* Frame Style Picker */}
      <div>
        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
          Select Frame / Card Style
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {FRAME_STYLES.map((fs) => {
            const isSelected = config.frameStyle === fs.id;
            return (
              <button
                key={fs.id}
                type="button"
                onClick={() => onChange({ frameStyle: fs.id })}
                className={`flex flex-col items-start p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-indigo-600/25 border-indigo-500 text-white shadow-md ring-1 ring-indigo-400'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="w-full flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold">{fs.label}</span>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-indigo-400" />}
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">{fs.desc}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Frame Text & Colors (If frame is enabled) */}
      {config.frameStyle !== 'none' ? (
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2">
            <LayoutTemplate className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-slate-200">Frame Customization</h3>
          </div>

          {/* CTA Text */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Call To Action (CTA) Text
            </label>
            <input
              type="text"
              value={config.frameText}
              onChange={(e) => onChange({ frameText: e.target.value })}
              placeholder="e.g. SCAN ME"
              maxLength={28}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm font-semibold tracking-wide text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Quick CTA Presets */}
          <div>
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 mb-2">
              <Sparkles className="w-3 h-3 text-amber-400" /> Quick Text Ideas
            </span>
            <div className="flex flex-wrap gap-1.5">
              {CTA_PRESETS.map((txt) => (
                <button
                  key={txt}
                  type="button"
                  onClick={() => onChange({ frameText: txt })}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-800/80 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-300 border border-slate-700/60 transition"
                >
                  {txt}
                </button>
              ))}
            </div>
          </div>

          {/* Frame Colors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Frame Background Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={config.frameColor}
                  onChange={(e) => onChange({ frameColor: e.target.value })}
                  className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={config.frameColor}
                  onChange={(e) => onChange({ frameColor: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Frame Text Color
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={config.frameTextColor}
                  onChange={(e) => onChange({ frameTextColor: e.target.value })}
                  className="w-10 h-9 rounded-xl bg-slate-950 border border-slate-700 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={config.frameTextColor}
                  onChange={(e) => onChange({ frameTextColor: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-xl font-mono text-xs text-slate-200"
                />
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 bg-slate-900/40 rounded-xl border border-slate-800 text-xs text-slate-400">
          Pure QR mode selected. The QR code will be generated cleanly without any outer frame or banner.
        </div>
      )}
    </div>
  );
};
