import React from 'react';
import { ShieldCheck, Download, Sparkles, Image as ImageIcon } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-800/80 bg-slate-950 mt-16 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 pb-8 border-b border-slate-800/60 text-xs">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-indigo-400 font-bold">
              <Sparkles className="w-4 h-4" />
              <span>Full Customization</span>
            </div>
            <p className="text-slate-400">
              Customize body dot shapes, corner eye frames (circus ke squares), gradients, and transparent backgrounds.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <ImageIcon className="w-4 h-4" />
              <span>Custom Center Logo</span>
            </div>
            <p className="text-slate-400">
              Upload your own brand logo or pick from popular social icons with automatic padding and high error correction.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>100% Scannable</span>
            </div>
            <p className="text-slate-400">
              Built-in scannability tester validates your QR code in real-time so your printed codes always work reliably.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <Download className="w-4 h-4" />
              <span>Crisp High-Res Downloads</span>
            </div>
            <p className="text-slate-400">
              Export as pure clean PNG, vector SVG, JPEG, or WEBP up to 4K resolution with zero loss of quality.
            </p>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>
            © {new Date().getFullYear()} QR Studio Pro — Built for designers, creators, and businesses.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-slate-400 font-medium">Free • No Watermarks • Instant Downloads</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
