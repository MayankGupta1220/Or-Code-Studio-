import React, { useState } from 'react';
import { 
  X, 
  ExternalLink, 
  Copy, 
  Check, 
  ShieldCheck, 
  Smartphone, 
  Wifi, 
  UserCheck, 
  MessageCircle, 
  CreditCard
} from 'lucide-react';
import { QRDataType } from '../types/qr';

interface ScanTesterModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: QRDataType;
  payload: string;
  summary: string;
}

export const ScanTesterModal: React.FC<ScanTesterModalProps> = ({
  isOpen,
  onClose,
  type,
  payload,
  summary,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(payload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isUrl = /^https?:\/\//i.test(payload);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Smartphone Scan Simulator</h3>
              <p className="text-xs text-slate-400">Preview what users see when pointing their camera</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Smartphone UI Mockup */}
        <div className="my-6">
          <div className="max-w-[340px] mx-auto bg-slate-950 border-4 border-slate-800 rounded-[2.5rem] p-4 shadow-2xl relative overflow-hidden">
            {/* Top Phone Notch */}
            <div className="w-24 h-4 bg-slate-800 rounded-full mx-auto mb-4" />

            {/* Camera Viewfinder Overlay */}
            <div className="relative aspect-[4/3] rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800/80 flex flex-col items-center justify-center p-4 text-center overflow-hidden">
              {/* Scan Reticle corners */}
              <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-indigo-500 rounded-tl-sm" />
              <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-indigo-500 rounded-tr-sm" />
              <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-indigo-500 rounded-bl-sm" />
              <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-indigo-500 rounded-br-sm" />

              <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-2">
                <ShieldCheck className="w-6 h-6 animate-pulse" />
              </div>
              <span className="text-[10px] font-mono text-emerald-400 font-semibold uppercase tracking-wider">
                QR Code Detected (100% Scannable)
              </span>

              {/* Floating iOS / Android Style Action Banner */}
              <div className="mt-4 w-full bg-slate-900/90 backdrop-blur border border-indigo-500/40 rounded-xl p-3 shadow-xl text-left animate-in slide-in-from-bottom duration-300">
                <div className="flex items-center gap-2 mb-1">
                  {type === 'url' && <ExternalLink className="w-3.5 h-3.5 text-indigo-400" />}
                  {type === 'wifi' && <Wifi className="w-3.5 h-3.5 text-cyan-400" />}
                  {type === 'vcard' && <UserCheck className="w-3.5 h-3.5 text-emerald-400" />}
                  {type === 'whatsapp' && <MessageCircle className="w-3.5 h-3.5 text-green-400" />}
                  {type === 'upi' && <CreditCard className="w-3.5 h-3.5 text-amber-400" />}
                  <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wide">
                    {type.toUpperCase()} Action
                  </span>
                </div>
                <p className="text-xs font-medium text-white truncate">
                  {summary}
                </p>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  Tap to execute on device
                </div>
              </div>
            </div>

            {/* Bottom bar */}
            <div className="w-28 h-1 bg-slate-700 rounded-full mx-auto mt-4" />
          </div>
        </div>

        {/* Encoded Content Inspector */}
        <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-400 uppercase tracking-wider">
              Exact Decoded Payload
            </span>
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 font-medium transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy Payload'}
            </button>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80 font-mono text-xs text-slate-300 break-all max-h-24 overflow-y-auto">
            {payload}
          </div>
        </div>

        {/* Actions */}
        <div className="mt-5 flex gap-2.5">
          {isUrl && (
            <a
              href={payload}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-lg shadow-indigo-600/30 transition"
            >
              <ExternalLink className="w-4 h-4" />
              Open Link in New Tab
            </a>
          )}
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs transition"
          >
            Close Simulator
          </button>
        </div>
      </div>
    </div>
  );
};
