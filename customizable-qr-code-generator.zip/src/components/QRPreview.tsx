import React, { useEffect, useRef, useState, useCallback } from 'react';
import QRCodeStyling from 'qr-code-styling';
import confetti from 'canvas-confetti';
import jsQR from 'jsqr';
import { 
  Download, 
  Copy, 
  Check, 
  Printer, 
  Smartphone, 
  ShieldCheck, 
  AlertTriangle, 
  Sparkles, 
  Maximize2
} from 'lucide-react';
import { QRConfig } from '../types/qr';
import { buildQRCodeStylingOptions, exportQRCode, downloadBlob, copyBlobToClipboard } from '../utils/qrExporter';

interface QRPreviewProps {
  payload: string;
  summary: string;
  config: QRConfig;
  onOpenSimulator: () => void;
  onSaveToHistory?: (previewUrl: string) => void;
}

type MockupType = 'studio' | 'phone' | 'table-stand' | 'sticker';

export const QRPreview: React.FC<QRPreviewProps> = ({
  payload,
  summary,
  config,
  onOpenSimulator,
  onSaveToHistory,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const qrCodeInstanceRef = useRef<QRCodeStyling | null>(null);

  // States
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [mockupMode, setMockupMode] = useState<MockupType>('studio');
  const [isScannable, setIsScannable] = useState<boolean | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);

  // Export settings state
  const [exportFormat, setExportFormat] = useState<'png' | 'svg' | 'jpeg' | 'webp'>('png');
  const [exportRes, setExportRes] = useState<number>(1024);
  const [exportPureOnly, setExportPureOnly] = useState<boolean>(false);

  // Initialize and update QRCodeStyling
  useEffect(() => {
    if (!containerRef.current) return;

    const stylingOptions = buildQRCodeStylingOptions(payload, config, 270);

    if (!qrCodeInstanceRef.current) {
      qrCodeInstanceRef.current = new QRCodeStyling({
        ...stylingOptions,
        type: 'canvas'
      });
      containerRef.current.innerHTML = '';
      qrCodeInstanceRef.current.append(containerRef.current);
    } else {
      if (containerRef.current.children.length === 0) {
        qrCodeInstanceRef.current.append(containerRef.current);
      }
      qrCodeInstanceRef.current.update(stylingOptions);
    }

    // Check scannability with jsQR
    const timer = setTimeout(() => {
      try {
        const canvas = containerRef.current?.querySelector('canvas');
        if (canvas) {
          const ctx = canvas.getContext('2d');
          if (ctx) {
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            setIsScannable(!!code);
          }
        }
      } catch {
        setIsScannable(true);
      }
    }, 450);

    return () => clearTimeout(timer);
  }, [payload, config, mockupMode]);

  // Quick 1-Click PNG Download (Pure or with Frame)
  const handleQuickDownload = async (pureQR: boolean = false) => {
    try {
      setDownloading(true);
      const { blob } = await exportQRCode(payload, config, {
        resolution: 1024,
        format: 'png',
        includeFrame: !pureQR && config.frameStyle !== 'none'
      });

      const fileName = `qr-code-${pureQR ? 'pure' : 'designer'}-${Date.now()}.png`;
      downloadBlob(blob, fileName);

      // Trigger celebration confetti
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 }
      });

      // Save to history thumbnail
      if (onSaveToHistory) {
        const previewUrl = URL.createObjectURL(blob);
        onSaveToHistory(previewUrl);
      }
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setDownloading(false);
    }
  };

  // Custom Full Export
  const handleCustomExport = async () => {
    try {
      setDownloading(true);
      const { blob } = await exportQRCode(payload, config, {
        resolution: exportRes,
        format: exportFormat,
        includeFrame: !exportPureOnly && config.frameStyle !== 'none'
      });

      const fileName = `qrcode-${exportRes}px.${exportFormat}`;
      downloadBlob(blob, fileName);

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.7 }
      });

      setShowExportModal(false);

      if (onSaveToHistory) {
        const previewUrl = URL.createObjectURL(blob);
        onSaveToHistory(previewUrl);
      }
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setDownloading(false);
    }
  };

  // Copy Image to Clipboard
  const handleCopyClipboard = async () => {
    try {
      const { blob } = await exportQRCode(payload, config, {
        resolution: 1024,
        format: 'png',
        includeFrame: config.frameStyle !== 'none'
      });

      const success = await copyBlobToClipboard(blob);
      if (success) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } else {
        alert('Direct clipboard copy is not supported in this browser. Please use the Download button.');
      }
    } catch (err) {
      console.error('Copy failed:', err);
    }
  };

  // Print Dialog
  const handlePrint = useCallback(async () => {
    try {
      const { blob } = await exportQRCode(payload, config, {
        resolution: 1200,
        format: 'png',
        includeFrame: config.frameStyle !== 'none'
      });

      const imgUrl = URL.createObjectURL(blob);
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Print QR Code - ${summary}</title>
              <style>
                body {
                  margin: 0;
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  justify-content: center;
                  min-height: 100vh;
                  font-family: sans-serif;
                  background: #fff;
                  color: #111;
                }
                img {
                  max-width: 480px;
                  max-height: 480px;
                  border-radius: 12px;
                }
                .caption {
                  margin-top: 16px;
                  font-size: 14px;
                  font-weight: 600;
                  color: #555;
                }
                @media print {
                  body { margin: 20mm; }
                }
              </style>
            </head>
            <body>
              <img src="${imgUrl}" onload="window.print();window.close();" />
              <div class="caption">${summary}</div>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
    } catch (err) {
      console.error('Print failed:', err);
    }
  }, [payload, config, summary]);

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Top Preview Controls / Mockup Switcher */}
      <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl">
        <div className="flex items-center gap-1">
          {[
            { id: 'studio', label: 'Studio Card' },
            { id: 'phone', label: 'Phone Mockup' },
            { id: 'table-stand', label: 'Table Stand' },
            { id: 'sticker', label: 'Sticker' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setMockupMode(item.id as MockupType)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                mockupMode === item.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Verification Status Badge */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-[11px]">
          {isScannable !== false ? (
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <ShieldCheck className="w-3.5 h-3.5" /> Scannable 100%
            </span>
          ) : (
            <span className="flex items-center gap-1 text-amber-400 font-medium" title="Contrast might be low or center logo is wide">
              <AlertTriangle className="w-3.5 h-3.5" /> Check Contrast
            </span>
          )}
        </div>
      </div>

      {/* Center Interactive Preview Area */}
      <div className="flex-1 min-h-[380px] bg-gradient-to-b from-slate-900/60 to-slate-950/80 border border-slate-800/80 rounded-3xl p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
        {/* Subtle grid background */}
        <div 
          className="absolute inset-0 opacity-15 pointer-events-none" 
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #6366f1 1px, transparent 0)`,
            backgroundSize: '24px 24px'
          }}
        />

        {/* Mockup Presentation Container */}
        <div className="w-full flex items-center justify-center">
          {/* PHONE MOCKUP WRAPPER */}
          {mockupMode === 'phone' && (
            <div className="w-[290px] bg-slate-950 border-[5px] border-slate-800 rounded-[2.8rem] p-3 shadow-2xl relative">
              <div className="w-20 h-3.5 bg-slate-800 rounded-full mx-auto mb-3" />
              <div className="bg-slate-900 rounded-[2rem] p-3.5 flex flex-col items-center">
                <div className="text-[10px] font-mono text-indigo-400 mb-2 font-semibold">
                  Scan Pass / Ticket
                </div>
                <div className="rounded-xl overflow-hidden p-1 shadow-inner" style={{ backgroundColor: config.bgColorType === 'transparent' ? '#ffffff' : config.bgColor }}>
                  <div
                    className={config.shape === 'circle' ? 'rounded-full overflow-hidden' : 'rounded-lg overflow-hidden'}
                  >
                    {/* The QR Canvas is placed here */}
                    <div ref={containerRef} className="transform scale-[0.85] origin-center -m-4" />
                  </div>
                </div>
                <div className="text-[11px] font-bold text-slate-100 mt-2 truncate max-w-[220px]">
                  {summary}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">
                  Hold near phone camera to test
                </div>
              </div>
              <div className="w-20 h-1 bg-slate-700 rounded-full mx-auto mt-3" />
            </div>
          )}

          {/* TABLE STAND MOCKUP WRAPPER */}
          {mockupMode === 'table-stand' && (
            <div className="flex flex-col items-center">
              <div className="w-[290px] bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-3.5 shadow-2xl flex flex-col items-center">
                <div className="w-full bg-slate-950/90 rounded-xl p-3 flex flex-col items-center text-center">
                  <div className="text-[11px] font-bold tracking-wider text-indigo-300 uppercase mb-2">
                    {config.frameText || 'TABLE ORDER / MENU'}
                  </div>
                  <div className="rounded-lg overflow-hidden p-1" style={{ backgroundColor: config.bgColorType === 'transparent' ? '#ffffff' : config.bgColor }}>
                    <div ref={containerRef} className="transform scale-[0.85] origin-center -m-4" />
                  </div>
                  <span className="text-[10px] text-slate-400 mt-2 font-medium">
                    Scan with any phone camera
                  </span>
                </div>
              </div>
              <div className="w-[310px] h-4 bg-amber-900/90 rounded-b-xl border-t-2 border-amber-700/60 shadow-xl" />
            </div>
          )}

          {/* STICKER MOCKUP WRAPPER */}
          {mockupMode === 'sticker' && (
            <div className="relative">
              <div
                className={`p-4 bg-white shadow-2xl border-4 border-slate-200 transition-all ${
                  config.shape === 'circle' ? 'rounded-full' : 'rounded-3xl'
                }`}
              >
                <div ref={containerRef} className="transform scale-[0.9] origin-center -m-2" />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-indigo-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                Die-Cut Vinyl
              </div>
            </div>
          )}

          {/* STUDIO / FRAMED CARD MODE (DEFAULT) */}
          {mockupMode === 'studio' && (
            <div
              className={`transition-all duration-300 relative ${
                config.frameStyle === 'bottom-banner'
                  ? 'overflow-hidden rounded-2xl shadow-2xl'
                  : config.frameStyle === 'top-badge'
                  ? 'overflow-hidden rounded-2xl shadow-2xl'
                  : config.frameStyle === 'polaroid'
                  ? 'p-4 rounded-2xl shadow-2xl text-center'
                  : config.frameStyle === 'modern-card'
                  ? 'p-5 rounded-3xl shadow-2xl text-center'
                  : config.frameStyle === 'badge-pill'
                  ? 'p-4 rounded-3xl shadow-2xl text-center'
                  : 'rounded-2xl shadow-xl'
              }`}
              style={{
                backgroundColor:
                  config.frameStyle === 'polaroid'
                    ? config.frameColor || '#ffffff'
                    : config.frameStyle === 'modern-card' || config.frameStyle === 'badge-pill'
                    ? config.frameColor || '#090d16'
                    : 'transparent',
                border: config.frameStyle !== 'none' ? '1px solid rgba(255,255,255,0.1)' : 'none'
              }}
            >
              {/* Top Badge Frame */}
              {config.frameStyle === 'top-badge' && (
                <div
                  className="py-2 px-4 text-center text-xs font-bold tracking-wider"
                  style={{
                    backgroundColor: config.frameColor,
                    color: config.frameTextColor
                  }}
                >
                  {config.frameText || 'SCAN ME'}
                </div>
              )}

              {/* Canvas QR Code Container */}
              <div
                ref={containerRef}
                className={`flex items-center justify-center transition-transform hover:scale-[1.01] ${
                  config.shape === 'circle' ? 'rounded-full overflow-hidden' : 'rounded-xl overflow-hidden'
                }`}
                style={{
                  backgroundColor:
                    config.bgColorType === 'transparent' ? 'transparent' : config.bgColor
                }}
              />

              {/* Bottom Banner Frame */}
              {config.frameStyle === 'bottom-banner' && (
                <div
                  className="py-2.5 px-4 text-center text-xs font-bold tracking-wider"
                  style={{
                    backgroundColor: config.frameColor,
                    color: config.frameTextColor
                  }}
                >
                  {config.frameText || 'SCAN ME'}
                </div>
              )}

              {/* Polaroid Title */}
              {config.frameStyle === 'polaroid' && (
                <div
                  className="pt-3 pb-1 text-center font-bold text-sm tracking-wide"
                  style={{ color: config.frameTextColor || '#000000' }}
                >
                  {config.frameText || 'SCAN ME'}
                </div>
              )}

              {/* Modern Card / Badge Pill */}
              {(config.frameStyle === 'modern-card' || config.frameStyle === 'badge-pill') && (
                <div className="pt-3 pb-1 flex justify-center">
                  <span
                    className="px-4 py-1.5 rounded-full text-xs font-bold shadow tracking-wider"
                    style={{
                      backgroundColor: config.frameTextColor || '#38bdf8',
                      color: config.frameColor || '#090d16'
                    }}
                  >
                    {config.frameText || 'SCAN ME'}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Payload preview chip at bottom of card */}
        <div className="mt-4 px-3 py-1.5 rounded-full bg-slate-950/70 border border-slate-800/80 text-xs text-slate-400 max-w-[90%] truncate">
          <span className="text-slate-500 mr-1">Target:</span>
          <span className="font-mono text-slate-300">{summary}</span>
        </div>
      </div>

      {/* Main Action Buttons Grid */}
      <div className="space-y-2.5">
        {/* Quick Download Buttons: Framed and Pure PNG */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {/* Button 1: Download Standard / Framed PNG */}
          <button
            type="button"
            disabled={downloading}
            onClick={() => handleQuickDownload(false)}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:scale-[0.99] text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{config.frameStyle !== 'none' ? 'Download Framed PNG' : 'Download PNG'}</span>
          </button>

          {/* Button 2: Download Pure Clean QR Image (Direct user requirement) */}
          <button
            type="button"
            disabled={downloading}
            onClick={() => handleQuickDownload(true)}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-[0.99] text-slate-100 font-semibold text-sm border border-slate-700 transition disabled:opacity-50"
            title="Download pure QR code without outer banner or frame"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Pure QR Only (PNG)</span>
          </button>
        </div>

        {/* Secondary Tool Bar: Copy, Test Scan, Custom Export, Print */}
        <div className="grid grid-cols-4 gap-2">
          {/* Copy to Clipboard */}
          <button
            type="button"
            onClick={handleCopyClipboard}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition"
            title="Copy PNG image directly to clipboard"
          >
            {copied ? (
              <Check className="w-4 h-4 text-emerald-400 mb-0.5" />
            ) : (
              <Copy className="w-4 h-4 text-indigo-400 mb-0.5" />
            )}
            <span className="text-[10px] font-medium">{copied ? 'Copied!' : 'Copy Img'}</span>
          </button>

          {/* Test Scanner Simulator */}
          <button
            type="button"
            onClick={onOpenSimulator}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition"
            title="Simulate smartphone scanning"
          >
            <Smartphone className="w-4 h-4 text-cyan-400 mb-0.5" />
            <span className="text-[10px] font-medium">Test Scan</span>
          </button>

          {/* Print Ready */}
          <button
            type="button"
            onClick={handlePrint}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition"
            title="Open printable sheet"
          >
            <Printer className="w-4 h-4 text-amber-400 mb-0.5" />
            <span className="text-[10px] font-medium">Print Sheet</span>
          </button>

          {/* High-Res & Vector SVG Options */}
          <button
            type="button"
            onClick={() => setShowExportModal(true)}
            className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition"
            title="Choose resolution and format (SVG, 4K, WEBP)"
          >
            <Maximize2 className="w-4 h-4 text-fuchsia-400 mb-0.5" />
            <span className="text-[10px] font-medium">4K / SVG</span>
          </button>
        </div>
      </div>

      {/* Advanced High-Res / Format Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div
            className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Maximize2 className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-slate-100">Export High-Resolution Image</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowExportModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded-lg bg-slate-800"
              >
                Close
              </button>
            </div>

            <div className="py-4 space-y-4">
              {/* Format selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Export File Format
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'png', label: 'PNG', desc: 'Standard' },
                    { id: 'svg', label: 'SVG', desc: 'Vector' },
                    { id: 'jpeg', label: 'JPEG', desc: 'Photo' },
                    { id: 'webp', label: 'WEBP', desc: 'Web' },
                  ].map((fmt) => (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => setExportFormat(fmt.id as any)}
                      className={`p-2.5 rounded-xl border text-center transition ${
                        exportFormat === fmt.id
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="text-xs font-bold uppercase">{fmt.label}</div>
                      <div className="text-[10px] opacity-75">{fmt.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Resolution (if raster) */}
              {exportFormat !== 'svg' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Image Resolution / Print Quality
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { px: 512, label: '512 px', tag: 'Web / Screen' },
                      { px: 1024, label: '1024 px', tag: 'Standard HD' },
                      { px: 2048, label: '2048 px', tag: 'Print / 4K' },
                    ].map((res) => (
                      <button
                        key={res.px}
                        type="button"
                        onClick={() => setExportRes(res.px)}
                        className={`p-2.5 rounded-xl border text-center transition ${
                          exportRes === res.px
                            ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                            : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="text-xs font-bold">{res.label}</div>
                        <div className="text-[10px] opacity-75">{res.tag}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Frame toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <span className="text-xs font-semibold text-slate-200 block">
                    Export Pure QR Only
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Omit outer banner, polaroid frame, or CTA buttons
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={exportPureOnly}
                  onChange={(e) => setExportPureOnly(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700 focus:ring-indigo-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Export trigger */}
            <button
              type="button"
              disabled={downloading}
              onClick={handleCustomExport}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>Download {exportFormat.toUpperCase()} ({exportFormat === 'svg' ? 'Vector' : `${exportRes}px`})</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
