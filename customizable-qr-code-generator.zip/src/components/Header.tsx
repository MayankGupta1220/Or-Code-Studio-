import React from 'react';
import { 
  QrCode, 
  Sparkles, 
  Clock, 
  Smartphone, 
  RotateCcw,
  Zap
} from 'lucide-react';

interface HeaderProps {
  historyCount: number;
  onOpenHistory: () => void;
  onOpenSimulator: () => void;
  onReset: () => void;
  onQuickPreset: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  historyCount,
  onOpenHistory,
  onOpenSimulator,
  onReset,
  onQuickPreset,
}) => {
  return (
    <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-xl sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 p-0.5 shadow-lg shadow-indigo-500/25 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <QrCode className="w-5 h-5 text-indigo-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-extrabold text-white tracking-tight font-['Space_Grotesk']">
                QR Studio <span className="bg-gradient-to-r from-indigo-400 to-fuchsia-400 bg-clip-text text-transparent">Pro</span>
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                <Zap className="w-3 h-3 text-amber-400" /> Designer Studio
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Custom dots, corner eyes, gradients & center logo generator
            </p>
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Quick Themes */}
          <button
            type="button"
            onClick={onQuickPreset}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Themes</span>
          </button>

          {/* Phone Scan Simulator */}
          <button
            type="button"
            onClick={onOpenSimulator}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white transition"
            title="Preview smartphone scanning"
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Scan Simulator</span>
          </button>

          {/* History Drawer */}
          <button
            type="button"
            onClick={onOpenHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white transition relative"
            title="Saved history"
          >
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden md:inline">History</span>
            {historyCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-mono">
                {historyCount}
              </span>
            )}
          </button>

          {/* Reset button */}
          <button
            type="button"
            onClick={onReset}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition"
            title="Reset to default settings"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
